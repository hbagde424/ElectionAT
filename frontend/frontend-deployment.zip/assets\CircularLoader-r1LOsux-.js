import{j as t,S as r,aM as e}from"./index-Ba4Gy4r-.js";function s(){return t.jsx(r,{alignItems:"center",justifyContent:"center",sx:{height:"100%"},children:t.jsx(e,{})})}export{s as C};
