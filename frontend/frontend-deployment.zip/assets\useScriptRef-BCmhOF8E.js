import{r}from"./index-Ba4Gy4r-.js";function s(){const e=r.useRef(!0);return r.useEffect(()=>()=>{e.current=!1},[]),e}export{s as u};
