import{P as x,V as pa,r as W,j as D,l as xr}from"./index-Ba4Gy4r-.js";import{L as X}from"./leaflet-CEkKdnlD.js";/*!
 * Font Awesome Free 7.0.0 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
 * Copyright 2025 Fonticons, Inc.
 */function We(e,t){(t==null||t>e.length)&&(t=e.length);for(var a=0,r=Array(t);a<t;a++)r[a]=e[a];return r}function wr(e){if(Array.isArray(e))return e}function Sr(e){if(Array.isArray(e))return We(e)}function Ar(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function kr(e,t){for(var a=0;a<t.length;a++){var r=t[a];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,va(r.key),r)}}function Er(e,t,a){return t&&kr(e.prototype,t),Object.defineProperty(e,"prototype",{writable:!1}),e}function be(e,t){var a=typeof Symbol<"u"&&e[Symbol.iterator]||e["@@iterator"];if(!a){if(Array.isArray(e)||(a=ot(e))||t){a&&(e=a);var r=0,n=function(){};return{s:n,n:function(){return r>=e.length?{done:!0}:{done:!1,value:e[r++]}},e:function(l){throw l},f:n}}throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var o,i=!0,s=!1;return{s:function(){a=a.call(e)},n:function(){var l=a.next();return i=l.done,l},e:function(l){s=!0,o=l},f:function(){try{i||a.return==null||a.return()}finally{if(s)throw o}}}}function A(e,t,a){return(t=va(t))in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}function Ir(e){if(typeof Symbol<"u"&&e[Symbol.iterator]!=null||e["@@iterator"]!=null)return Array.from(e)}function Pr(e,t){var a=e==null?null:typeof Symbol<"u"&&e[Symbol.iterator]||e["@@iterator"];if(a!=null){var r,n,o,i,s=[],l=!0,c=!1;try{if(o=(a=a.call(e)).next,t===0){if(Object(a)!==a)return;l=!1}else for(;!(l=(r=o.call(a)).done)&&(s.push(r.value),s.length!==t);l=!0);}catch(m){c=!0,n=m}finally{try{if(!l&&a.return!=null&&(i=a.return(),Object(i)!==i))return}finally{if(c)throw n}}return s}}function Nr(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function Cr(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function Tt(e,t){var a=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(n){return Object.getOwnPropertyDescriptor(e,n).enumerable})),a.push.apply(a,r)}return a}function f(e){for(var t=1;t<arguments.length;t++){var a=arguments[t]!=null?arguments[t]:{};t%2?Tt(Object(a),!0).forEach(function(r){A(e,r,a[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(a)):Tt(Object(a)).forEach(function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(a,r))})}return e}function Pe(e,t){return wr(e)||Pr(e,t)||ot(e,t)||Nr()}function R(e){return Sr(e)||Ir(e)||ot(e)||Cr()}function Or(e,t){if(typeof e!="object"||!e)return e;var a=e[Symbol.toPrimitive];if(a!==void 0){var r=a.call(e,t||"default");if(typeof r!="object")return r;throw new TypeError("@@toPrimitive must return a primitive value.")}return(t==="string"?String:Number)(e)}function va(e){var t=Or(e,"string");return typeof t=="symbol"?t:t+""}function Se(e){"@babel/helpers - typeof";return Se=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(t){return typeof t}:function(t){return t&&typeof Symbol=="function"&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},Se(e)}function ot(e,t){if(e){if(typeof e=="string")return We(e,t);var a={}.toString.call(e).slice(8,-1);return a==="Object"&&e.constructor&&(a=e.constructor.name),a==="Map"||a==="Set"?Array.from(e):a==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a)?We(e,t):void 0}}var _t=function(){},it={},ga={},ha=null,ya={mark:_t,measure:_t};try{typeof window<"u"&&(it=window),typeof document<"u"&&(ga=document),typeof MutationObserver<"u"&&(ha=MutationObserver),typeof performance<"u"&&(ya=performance)}catch{}var Fr=it.navigator||{},$t=Fr.userAgent,Dt=$t===void 0?"":$t,q=it,C=ga,Lt=ha,he=ya;q.document;var G=!!C.documentElement&&!!C.head&&typeof C.addEventListener=="function"&&typeof C.createElement=="function",ba=~Dt.indexOf("MSIE")||~Dt.indexOf("Trident/"),Te,jr=/fa(k|kd|s|r|l|t|d|dr|dl|dt|b|slr|slpr|wsb|tl|ns|nds|es|jr|jfr|jdr|cr|ss|sr|sl|st|sds|sdr|sdl|sdt)?[\-\ ]/,Tr=/Font ?Awesome ?([567 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp Duotone|Sharp|Kit|Notdog Duo|Notdog|Chisel|Etch|Thumbprint|Jelly Fill|Jelly Duo|Jelly|Slab Press|Slab|Whiteboard)?.*/i,xa={classic:{fa:"solid",fas:"solid","fa-solid":"solid",far:"regular","fa-regular":"regular",fal:"light","fa-light":"light",fat:"thin","fa-thin":"thin",fab:"brands","fa-brands":"brands"},duotone:{fa:"solid",fad:"solid","fa-solid":"solid","fa-duotone":"solid",fadr:"regular","fa-regular":"regular",fadl:"light","fa-light":"light",fadt:"thin","fa-thin":"thin"},sharp:{fa:"solid",fass:"solid","fa-solid":"solid",fasr:"regular","fa-regular":"regular",fasl:"light","fa-light":"light",fast:"thin","fa-thin":"thin"},"sharp-duotone":{fa:"solid",fasds:"solid","fa-solid":"solid",fasdr:"regular","fa-regular":"regular",fasdl:"light","fa-light":"light",fasdt:"thin","fa-thin":"thin"},slab:{"fa-regular":"regular",faslr:"regular"},"slab-press":{"fa-regular":"regular",faslpr:"regular"},thumbprint:{"fa-light":"light",fatl:"light"},whiteboard:{"fa-semibold":"semibold",fawsb:"semibold"},notdog:{"fa-solid":"solid",fans:"solid"},"notdog-duo":{"fa-solid":"solid",fands:"solid"},etch:{"fa-solid":"solid",faes:"solid"},jelly:{"fa-regular":"regular",fajr:"regular"},"jelly-fill":{"fa-regular":"regular",fajfr:"regular"},"jelly-duo":{"fa-regular":"regular",fajdr:"regular"},chisel:{"fa-regular":"regular",facr:"regular"}},_r={GROUP:"duotone-group",SWAP_OPACITY:"swap-opacity",PRIMARY:"primary",SECONDARY:"secondary"},wa=["fa-classic","fa-duotone","fa-sharp","fa-sharp-duotone","fa-thumbprint","fa-whiteboard","fa-notdog","fa-notdog-duo","fa-chisel","fa-etch","fa-jelly","fa-jelly-fill","fa-jelly-duo","fa-slab","fa-slab-press"],j="classic",pe="duotone",Sa="sharp",Aa="sharp-duotone",ka="chisel",Ea="etch",Ia="jelly",Pa="jelly-duo",Na="jelly-fill",Ca="notdog",Oa="notdog-duo",Fa="slab",ja="slab-press",Ta="thumbprint",_a="whiteboard",$r="Classic",Dr="Duotone",Lr="Sharp",Mr="Sharp Duotone",Rr="Chisel",zr="Etch",Wr="Jelly",Br="Jelly Duo",Vr="Jelly Fill",Yr="Notdog",Ur="Notdog Duo",Hr="Slab",Gr="Slab Press",Xr="Thumbprint",Kr="Whiteboard",$a=[j,pe,Sa,Aa,ka,Ea,Ia,Pa,Na,Ca,Oa,Fa,ja,Ta,_a];Te={},A(A(A(A(A(A(A(A(A(A(Te,j,$r),pe,Dr),Sa,Lr),Aa,Mr),ka,Rr),Ea,zr),Ia,Wr),Pa,Br),Na,Vr),Ca,Yr),A(A(A(A(A(Te,Oa,Ur),Fa,Hr),ja,Gr),Ta,Xr),_a,Kr);var Jr={classic:{900:"fas",400:"far",normal:"far",300:"fal",100:"fat"},duotone:{900:"fad",400:"fadr",300:"fadl",100:"fadt"},sharp:{900:"fass",400:"fasr",300:"fasl",100:"fast"},"sharp-duotone":{900:"fasds",400:"fasdr",300:"fasdl",100:"fasdt"},slab:{400:"faslr"},"slab-press":{400:"faslpr"},whiteboard:{600:"fawsb"},thumbprint:{300:"fatl"},notdog:{900:"fans"},"notdog-duo":{900:"fands"},etch:{900:"faes"},chisel:{400:"facr"},jelly:{400:"fajr"},"jelly-fill":{400:"fajfr"},"jelly-duo":{400:"fajdr"}},qr={"Font Awesome 7 Free":{900:"fas",400:"far"},"Font Awesome 7 Pro":{900:"fas",400:"far",normal:"far",300:"fal",100:"fat"},"Font Awesome 7 Brands":{400:"fab",normal:"fab"},"Font Awesome 7 Duotone":{900:"fad",400:"fadr",normal:"fadr",300:"fadl",100:"fadt"},"Font Awesome 7 Sharp":{900:"fass",400:"fasr",normal:"fasr",300:"fasl",100:"fast"},"Font Awesome 7 Sharp Duotone":{900:"fasds",400:"fasdr",normal:"fasdr",300:"fasdl",100:"fasdt"},"Font Awesome 7 Jelly":{400:"fajr",normal:"fajr"},"Font Awesome 7 Jelly Fill":{400:"fajfr",normal:"fajfr"},"Font Awesome 7 Jelly Duo":{400:"fajdr",normal:"fajdr"},"Font Awesome 7 Slab":{400:"faslr",normal:"faslr"},"Font Awesome 7 Slab Press":{400:"faslpr",normal:"faslpr"},"Font Awesome 7 Thumbprint":{300:"fatl",normal:"fatl"},"Font Awesome 7 Notdog":{900:"fans",normal:"fans"},"Font Awesome 7 Notdog Duo":{900:"fands",normal:"fands"},"Font Awesome 7 Etch":{900:"faes",normal:"faes"},"Font Awesome 7 Chisel":{400:"facr",normal:"facr"},"Font Awesome 7 Whiteboard":{600:"fawsb",normal:"fawsb"}},Zr=new Map([["classic",{defaultShortPrefixId:"fas",defaultStyleId:"solid",styleIds:["solid","regular","light","thin","brands"],futureStyleIds:[],defaultFontWeight:900}],["duotone",{defaultShortPrefixId:"fad",defaultStyleId:"solid",styleIds:["solid","regular","light","thin"],futureStyleIds:[],defaultFontWeight:900}],["sharp",{defaultShortPrefixId:"fass",defaultStyleId:"solid",styleIds:["solid","regular","light","thin"],futureStyleIds:[],defaultFontWeight:900}],["sharp-duotone",{defaultShortPrefixId:"fasds",defaultStyleId:"solid",styleIds:["solid","regular","light","thin"],futureStyleIds:[],defaultFontWeight:900}],["chisel",{defaultShortPrefixId:"facr",defaultStyleId:"regular",styleIds:["regular"],futureStyleIds:[],defaultFontWeight:400}],["etch",{defaultShortPrefixId:"faes",defaultStyleId:"solid",styleIds:["solid"],futureStyleIds:[],defaultFontWeight:900}],["jelly",{defaultShortPrefixId:"fajr",defaultStyleId:"regular",styleIds:["regular"],futureStyleIds:[],defaultFontWeight:400}],["jelly-duo",{defaultShortPrefixId:"fajdr",defaultStyleId:"regular",styleIds:["regular"],futureStyleIds:[],defaultFontWeight:400}],["jelly-fill",{defaultShortPrefixId:"fajfr",defaultStyleId:"regular",styleIds:["regular"],futureStyleIds:[],defaultFontWeight:400}],["notdog",{defaultShortPrefixId:"fans",defaultStyleId:"solid",styleIds:["solid"],futureStyleIds:[],defaultFontWeight:900}],["notdog-duo",{defaultShortPrefixId:"fands",defaultStyleId:"solid",styleIds:["solid"],futureStyleIds:[],defaultFontWeight:900}],["slab",{defaultShortPrefixId:"faslr",defaultStyleId:"regular",styleIds:["regular"],futureStyleIds:[],defaultFontWeight:400}],["slab-press",{defaultShortPrefixId:"faslpr",defaultStyleId:"regular",styleIds:["regular"],futureStyleIds:[],defaultFontWeight:400}],["thumbprint",{defaultShortPrefixId:"fatl",defaultStyleId:"light",styleIds:["light"],futureStyleIds:[],defaultFontWeight:300}],["whiteboard",{defaultShortPrefixId:"fawsb",defaultStyleId:"semibold",styleIds:["semibold"],futureStyleIds:[],defaultFontWeight:600}]]),Qr={chisel:{regular:"facr"},classic:{brands:"fab",light:"fal",regular:"far",solid:"fas",thin:"fat"},duotone:{light:"fadl",regular:"fadr",solid:"fad",thin:"fadt"},etch:{solid:"faes"},jelly:{regular:"fajr"},"jelly-duo":{regular:"fajdr"},"jelly-fill":{regular:"fajfr"},notdog:{solid:"fans"},"notdog-duo":{solid:"fands"},sharp:{light:"fasl",regular:"fasr",solid:"fass",thin:"fast"},"sharp-duotone":{light:"fasdl",regular:"fasdr",solid:"fasds",thin:"fasdt"},slab:{regular:"faslr"},"slab-press":{regular:"faslpr"},thumbprint:{light:"fatl"},whiteboard:{semibold:"fawsb"}},Da=["fak","fa-kit","fakd","fa-kit-duotone"],Mt={kit:{fak:"kit","fa-kit":"kit"},"kit-duotone":{fakd:"kit-duotone","fa-kit-duotone":"kit-duotone"}},en=["kit"],tn="kit",an="kit-duotone",rn="Kit",nn="Kit Duotone";A(A({},tn,rn),an,nn);var on={kit:{"fa-kit":"fak"},"kit-duotone":{"fa-kit-duotone":"fakd"}},sn={"Font Awesome Kit":{400:"fak",normal:"fak"},"Font Awesome Kit Duotone":{400:"fakd",normal:"fakd"}},ln={kit:{fak:"fa-kit"},"kit-duotone":{fakd:"fa-kit-duotone"}},Rt={kit:{kit:"fak"},"kit-duotone":{"kit-duotone":"fakd"}},_e,ye={GROUP:"duotone-group",SWAP_OPACITY:"swap-opacity",PRIMARY:"primary",SECONDARY:"secondary"},fn=["fa-classic","fa-duotone","fa-sharp","fa-sharp-duotone","fa-thumbprint","fa-whiteboard","fa-notdog","fa-notdog-duo","fa-chisel","fa-etch","fa-jelly","fa-jelly-fill","fa-jelly-duo","fa-slab","fa-slab-press"],cn="classic",un="duotone",dn="sharp",mn="sharp-duotone",pn="chisel",vn="etch",gn="jelly",hn="jelly-duo",yn="jelly-fill",bn="notdog",xn="notdog-duo",wn="slab",Sn="slab-press",An="thumbprint",kn="whiteboard",En="Classic",In="Duotone",Pn="Sharp",Nn="Sharp Duotone",Cn="Chisel",On="Etch",Fn="Jelly",jn="Jelly Duo",Tn="Jelly Fill",_n="Notdog",$n="Notdog Duo",Dn="Slab",Ln="Slab Press",Mn="Thumbprint",Rn="Whiteboard";_e={},A(A(A(A(A(A(A(A(A(A(_e,cn,En),un,In),dn,Pn),mn,Nn),pn,Cn),vn,On),gn,Fn),hn,jn),yn,Tn),bn,_n),A(A(A(A(A(_e,xn,$n),wn,Dn),Sn,Ln),An,Mn),kn,Rn);var zn="kit",Wn="kit-duotone",Bn="Kit",Vn="Kit Duotone";A(A({},zn,Bn),Wn,Vn);var Yn={classic:{"fa-brands":"fab","fa-duotone":"fad","fa-light":"fal","fa-regular":"far","fa-solid":"fas","fa-thin":"fat"},duotone:{"fa-regular":"fadr","fa-light":"fadl","fa-thin":"fadt"},sharp:{"fa-solid":"fass","fa-regular":"fasr","fa-light":"fasl","fa-thin":"fast"},"sharp-duotone":{"fa-solid":"fasds","fa-regular":"fasdr","fa-light":"fasdl","fa-thin":"fasdt"},slab:{"fa-regular":"faslr"},"slab-press":{"fa-regular":"faslpr"},whiteboard:{"fa-semibold":"fawsb"},thumbprint:{"fa-light":"fatl"},notdog:{"fa-solid":"fans"},"notdog-duo":{"fa-solid":"fands"},etch:{"fa-solid":"faes"},jelly:{"fa-regular":"fajr"},"jelly-fill":{"fa-regular":"fajfr"},"jelly-duo":{"fa-regular":"fajdr"},chisel:{"fa-regular":"facr"}},Un={classic:["fas","far","fal","fat","fad"],duotone:["fadr","fadl","fadt"],sharp:["fass","fasr","fasl","fast"],"sharp-duotone":["fasds","fasdr","fasdl","fasdt"],slab:["faslr"],"slab-press":["faslpr"],whiteboard:["fawsb"],thumbprint:["fatl"],notdog:["fans"],"notdog-duo":["fands"],etch:["faes"],jelly:["fajr"],"jelly-fill":["fajfr"],"jelly-duo":["fajdr"],chisel:["facr"]},Be={classic:{fab:"fa-brands",fad:"fa-duotone",fal:"fa-light",far:"fa-regular",fas:"fa-solid",fat:"fa-thin"},duotone:{fadr:"fa-regular",fadl:"fa-light",fadt:"fa-thin"},sharp:{fass:"fa-solid",fasr:"fa-regular",fasl:"fa-light",fast:"fa-thin"},"sharp-duotone":{fasds:"fa-solid",fasdr:"fa-regular",fasdl:"fa-light",fasdt:"fa-thin"},slab:{faslr:"fa-regular"},"slab-press":{faslpr:"fa-regular"},whiteboard:{fawsb:"fa-semibold"},thumbprint:{fatl:"fa-light"},notdog:{fans:"fa-solid"},"notdog-duo":{fands:"fa-solid"},etch:{faes:"fa-solid"},jelly:{fajr:"fa-regular"},"jelly-fill":{fajfr:"fa-regular"},"jelly-duo":{fajdr:"fa-regular"},chisel:{facr:"fa-regular"}},Hn=["fa-solid","fa-regular","fa-light","fa-thin","fa-duotone","fa-brands","fa-semibold"],La=["fa","fas","far","fal","fat","fad","fadr","fadl","fadt","fab","fass","fasr","fasl","fast","fasds","fasdr","fasdl","fasdt","faslr","faslpr","fawsb","fatl","fans","fands","faes","fajr","fajfr","fajdr","facr"].concat(fn,Hn),Gn=["solid","regular","light","thin","duotone","brands","semibold"],Ma=[1,2,3,4,5,6,7,8,9,10],Xn=Ma.concat([11,12,13,14,15,16,17,18,19,20]),Kn=["aw","fw","pull-left","pull-right"],Jn=[].concat(R(Object.keys(Un)),Gn,Kn,["2xs","xs","sm","lg","xl","2xl","beat","border","fade","beat-fade","bounce","flip-both","flip-horizontal","flip-vertical","flip","inverse","layers","layers-bottom-left","layers-bottom-right","layers-counter","layers-text","layers-top-left","layers-top-right","li","pull-end","pull-start","pulse","rotate-180","rotate-270","rotate-90","rotate-by","shake","spin-pulse","spin-reverse","spin","stack-1x","stack-2x","stack","ul","width-auto","width-fixed",ye.GROUP,ye.SWAP_OPACITY,ye.PRIMARY,ye.SECONDARY]).concat(Ma.map(function(e){return"".concat(e,"x")})).concat(Xn.map(function(e){return"w-".concat(e)})),qn={"Font Awesome 5 Free":{900:"fas",400:"far"},"Font Awesome 5 Pro":{900:"fas",400:"far",normal:"far",300:"fal"},"Font Awesome 5 Brands":{400:"fab",normal:"fab"},"Font Awesome 5 Duotone":{900:"fad"}},U="___FONT_AWESOME___",Ve=16,Ra="fa",za="svg-inline--fa",te="data-fa-i2svg",Ye="data-fa-pseudo-element",Zn="data-fa-pseudo-element-pending",st="data-prefix",lt="data-icon",zt="fontawesome-i2svg",Qn="async",eo=["HTML","HEAD","STYLE","SCRIPT"],Wa=["::before","::after",":before",":after"],Ba=function(){try{return!0}catch{return!1}}();function ve(e){return new Proxy(e,{get:function(a,r){return r in a?a[r]:a[j]}})}var Va=f({},xa);Va[j]=f(f(f(f({},{"fa-duotone":"duotone"}),xa[j]),Mt.kit),Mt["kit-duotone"]);var to=ve(Va),Ue=f({},Qr);Ue[j]=f(f(f(f({},{duotone:"fad"}),Ue[j]),Rt.kit),Rt["kit-duotone"]);var Wt=ve(Ue),He=f({},Be);He[j]=f(f({},He[j]),ln.kit);var Ya=ve(He),Ge=f({},Yn);Ge[j]=f(f({},Ge[j]),on.kit);ve(Ge);var ao=jr,Ua="fa-layers-text",ro=Tr,no=f({},Jr);ve(no);var oo=["class","data-prefix","data-icon","data-fa-transform","data-fa-mask"],$e=_r,io=[].concat(R(en),R(Jn)),ue=q.FontAwesomeConfig||{};function so(e){var t=C.querySelector("script["+e+"]");if(t)return t.getAttribute(e)}function lo(e){return e===""?!0:e==="false"?!1:e==="true"?!0:e}if(C&&typeof C.querySelector=="function"){var fo=[["data-family-prefix","familyPrefix"],["data-css-prefix","cssPrefix"],["data-family-default","familyDefault"],["data-style-default","styleDefault"],["data-replacement-class","replacementClass"],["data-auto-replace-svg","autoReplaceSvg"],["data-auto-add-css","autoAddCss"],["data-search-pseudo-elements","searchPseudoElements"],["data-search-pseudo-elements-warnings","searchPseudoElementsWarnings"],["data-search-pseudo-elements-full-scan","searchPseudoElementsFullScan"],["data-observe-mutations","observeMutations"],["data-mutate-approach","mutateApproach"],["data-keep-original-source","keepOriginalSource"],["data-measure-performance","measurePerformance"],["data-show-missing-icons","showMissingIcons"]];fo.forEach(function(e){var t=Pe(e,2),a=t[0],r=t[1],n=lo(so(a));n!=null&&(ue[r]=n)})}var Ha={styleDefault:"solid",familyDefault:j,cssPrefix:Ra,replacementClass:za,autoReplaceSvg:!0,autoAddCss:!0,searchPseudoElements:!1,searchPseudoElementsWarnings:!0,searchPseudoElementsFullScan:!1,observeMutations:!0,mutateApproach:"async",keepOriginalSource:!0,measurePerformance:!1,showMissingIcons:!0};ue.familyPrefix&&(ue.cssPrefix=ue.familyPrefix);var ie=f(f({},Ha),ue);ie.autoReplaceSvg||(ie.observeMutations=!1);var g={};Object.keys(Ha).forEach(function(e){Object.defineProperty(g,e,{enumerable:!0,set:function(a){ie[e]=a,de.forEach(function(r){return r(g)})},get:function(){return ie[e]}})});Object.defineProperty(g,"familyPrefix",{enumerable:!0,set:function(t){ie.cssPrefix=t,de.forEach(function(a){return a(g)})},get:function(){return ie.cssPrefix}});q.FontAwesomeConfig=g;var de=[];function co(e){return de.push(e),function(){de.splice(de.indexOf(e),1)}}var K=Ve,V={size:16,x:0,y:0,rotate:0,flipX:!1,flipY:!1};function uo(e){if(!(!e||!G)){var t=C.createElement("style");t.setAttribute("type","text/css"),t.innerHTML=e;for(var a=C.head.childNodes,r=null,n=a.length-1;n>-1;n--){var o=a[n],i=(o.tagName||"").toUpperCase();["STYLE","LINK"].indexOf(i)>-1&&(r=o)}return C.head.insertBefore(t,r),e}}var mo="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";function Bt(){for(var e=12,t="";e-- >0;)t+=mo[Math.random()*62|0];return t}function se(e){for(var t=[],a=(e||[]).length>>>0;a--;)t[a]=e[a];return t}function ft(e){return e.classList?se(e.classList):(e.getAttribute("class")||"").split(" ").filter(function(t){return t})}function Ga(e){return"".concat(e).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function po(e){return Object.keys(e||{}).reduce(function(t,a){return t+"".concat(a,'="').concat(Ga(e[a]),'" ')},"").trim()}function Ne(e){return Object.keys(e||{}).reduce(function(t,a){return t+"".concat(a,": ").concat(e[a].trim(),";")},"")}function ct(e){return e.size!==V.size||e.x!==V.x||e.y!==V.y||e.rotate!==V.rotate||e.flipX||e.flipY}function vo(e){var t=e.transform,a=e.containerWidth,r=e.iconWidth,n={transform:"translate(".concat(a/2," 256)")},o="translate(".concat(t.x*32,", ").concat(t.y*32,") "),i="scale(".concat(t.size/16*(t.flipX?-1:1),", ").concat(t.size/16*(t.flipY?-1:1),") "),s="rotate(".concat(t.rotate," 0 0)"),l={transform:"".concat(o," ").concat(i," ").concat(s)},c={transform:"translate(".concat(r/2*-1," -256)")};return{outer:n,inner:l,path:c}}function go(e){var t=e.transform,a=e.width,r=a===void 0?Ve:a,n=e.height,o=n===void 0?Ve:n,i=e.startCentered,s=i===void 0?!1:i,l="";return s&&ba?l+="translate(".concat(t.x/K-r/2,"em, ").concat(t.y/K-o/2,"em) "):s?l+="translate(calc(-50% + ".concat(t.x/K,"em), calc(-50% + ").concat(t.y/K,"em)) "):l+="translate(".concat(t.x/K,"em, ").concat(t.y/K,"em) "),l+="scale(".concat(t.size/K*(t.flipX?-1:1),", ").concat(t.size/K*(t.flipY?-1:1),") "),l+="rotate(".concat(t.rotate,"deg) "),l}var ho=`:root, :host {
  --fa-font-solid: normal 900 1em/1 "Font Awesome 7 Free";
  --fa-font-regular: normal 400 1em/1 "Font Awesome 7 Free";
  --fa-font-light: normal 300 1em/1 "Font Awesome 7 Pro";
  --fa-font-thin: normal 100 1em/1 "Font Awesome 7 Pro";
  --fa-font-duotone: normal 900 1em/1 "Font Awesome 7 Duotone";
  --fa-font-duotone-regular: normal 400 1em/1 "Font Awesome 7 Duotone";
  --fa-font-duotone-light: normal 300 1em/1 "Font Awesome 7 Duotone";
  --fa-font-duotone-thin: normal 100 1em/1 "Font Awesome 7 Duotone";
  --fa-font-brands: normal 400 1em/1 "Font Awesome 7 Brands";
  --fa-font-sharp-solid: normal 900 1em/1 "Font Awesome 7 Sharp";
  --fa-font-sharp-regular: normal 400 1em/1 "Font Awesome 7 Sharp";
  --fa-font-sharp-light: normal 300 1em/1 "Font Awesome 7 Sharp";
  --fa-font-sharp-thin: normal 100 1em/1 "Font Awesome 7 Sharp";
  --fa-font-sharp-duotone-solid: normal 900 1em/1 "Font Awesome 7 Sharp Duotone";
  --fa-font-sharp-duotone-regular: normal 400 1em/1 "Font Awesome 7 Sharp Duotone";
  --fa-font-sharp-duotone-light: normal 300 1em/1 "Font Awesome 7 Sharp Duotone";
  --fa-font-sharp-duotone-thin: normal 100 1em/1 "Font Awesome 7 Sharp Duotone";
  --fa-font-slab-regular: normal 400 1em/1 "Font Awesome 7 Slab";
  --fa-font-slab-press-regular: normal 400 1em/1 "Font Awesome 7 Slab Press";
  --fa-font-whiteboard-semibold: normal 600 1em/1 "Font Awesome 7 Whiteboard";
  --fa-font-thumbprint-light: normal 300 1em/1 "Font Awesome 7 Thumbprint";
  --fa-font-notdog-solid: normal 900 1em/1 "Font Awesome 7 Notdog";
  --fa-font-notdog-duo-solid: normal 900 1em/1 "Font Awesome 7 Notdog Duo";
  --fa-font-etch-solid: normal 900 1em/1 "Font Awesome 7 Etch";
  --fa-font-jelly-regular: normal 400 1em/1 "Font Awesome 7 Jelly";
  --fa-font-jelly-fill-regular: normal 400 1em/1 "Font Awesome 7 Jelly Fill";
  --fa-font-jelly-duo-regular: normal 400 1em/1 "Font Awesome 7 Jelly Duo";
  --fa-font-chisel-regular: normal 400 1em/1 "Font Awesome 7 Chisel";
}

.svg-inline--fa {
  box-sizing: content-box;
  display: var(--fa-display, inline-block);
  height: 1em;
  overflow: visible;
  vertical-align: -0.125em;
  width: var(--fa-width, 1.25em);
}
.svg-inline--fa.fa-2xs {
  vertical-align: 0.1em;
}
.svg-inline--fa.fa-xs {
  vertical-align: 0em;
}
.svg-inline--fa.fa-sm {
  vertical-align: -0.0714285714em;
}
.svg-inline--fa.fa-lg {
  vertical-align: -0.2em;
}
.svg-inline--fa.fa-xl {
  vertical-align: -0.25em;
}
.svg-inline--fa.fa-2xl {
  vertical-align: -0.3125em;
}
.svg-inline--fa.fa-pull-left,
.svg-inline--fa .fa-pull-start {
  float: inline-start;
  margin-inline-end: var(--fa-pull-margin, 0.3em);
}
.svg-inline--fa.fa-pull-right,
.svg-inline--fa .fa-pull-end {
  float: inline-end;
  margin-inline-start: var(--fa-pull-margin, 0.3em);
}
.svg-inline--fa.fa-li {
  width: var(--fa-li-width, 2em);
  inset-inline-start: calc(-1 * var(--fa-li-width, 2em));
  inset-block-start: 0.25em; /* syncing vertical alignment with Web Font rendering */
}

.fa-layers-counter, .fa-layers-text {
  display: inline-block;
  position: absolute;
  text-align: center;
}

.fa-layers {
  display: inline-block;
  height: 1em;
  position: relative;
  text-align: center;
  vertical-align: -0.125em;
  width: var(--fa-width, 1.25em);
}
.fa-layers .svg-inline--fa {
  inset: 0;
  margin: auto;
  position: absolute;
  transform-origin: center center;
}

.fa-layers-text {
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  transform-origin: center center;
}

.fa-layers-counter {
  background-color: var(--fa-counter-background-color, #ff253a);
  border-radius: var(--fa-counter-border-radius, 1em);
  box-sizing: border-box;
  color: var(--fa-inverse, #fff);
  line-height: var(--fa-counter-line-height, 1);
  max-width: var(--fa-counter-max-width, 5em);
  min-width: var(--fa-counter-min-width, 1.5em);
  overflow: hidden;
  padding: var(--fa-counter-padding, 0.25em 0.5em);
  right: var(--fa-right, 0);
  text-overflow: ellipsis;
  top: var(--fa-top, 0);
  transform: scale(var(--fa-counter-scale, 0.25));
  transform-origin: top right;
}

.fa-layers-bottom-right {
  bottom: var(--fa-bottom, 0);
  right: var(--fa-right, 0);
  top: auto;
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: bottom right;
}

.fa-layers-bottom-left {
  bottom: var(--fa-bottom, 0);
  left: var(--fa-left, 0);
  right: auto;
  top: auto;
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: bottom left;
}

.fa-layers-top-right {
  top: var(--fa-top, 0);
  right: var(--fa-right, 0);
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: top right;
}

.fa-layers-top-left {
  left: var(--fa-left, 0);
  right: auto;
  top: var(--fa-top, 0);
  transform: scale(var(--fa-layers-scale, 0.25));
  transform-origin: top left;
}

.fa-1x {
  font-size: 1em;
}

.fa-2x {
  font-size: 2em;
}

.fa-3x {
  font-size: 3em;
}

.fa-4x {
  font-size: 4em;
}

.fa-5x {
  font-size: 5em;
}

.fa-6x {
  font-size: 6em;
}

.fa-7x {
  font-size: 7em;
}

.fa-8x {
  font-size: 8em;
}

.fa-9x {
  font-size: 9em;
}

.fa-10x {
  font-size: 10em;
}

.fa-2xs {
  font-size: calc(10 / 16 * 1em); /* converts a 10px size into an em-based value that's relative to the scale's 16px base */
  line-height: calc(1 / 10 * 1em); /* sets the line-height of the icon back to that of it's parent */
  vertical-align: calc((6 / 10 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */
}

.fa-xs {
  font-size: calc(12 / 16 * 1em); /* converts a 12px size into an em-based value that's relative to the scale's 16px base */
  line-height: calc(1 / 12 * 1em); /* sets the line-height of the icon back to that of it's parent */
  vertical-align: calc((6 / 12 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */
}

.fa-sm {
  font-size: calc(14 / 16 * 1em); /* converts a 14px size into an em-based value that's relative to the scale's 16px base */
  line-height: calc(1 / 14 * 1em); /* sets the line-height of the icon back to that of it's parent */
  vertical-align: calc((6 / 14 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */
}

.fa-lg {
  font-size: calc(20 / 16 * 1em); /* converts a 20px size into an em-based value that's relative to the scale's 16px base */
  line-height: calc(1 / 20 * 1em); /* sets the line-height of the icon back to that of it's parent */
  vertical-align: calc((6 / 20 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */
}

.fa-xl {
  font-size: calc(24 / 16 * 1em); /* converts a 24px size into an em-based value that's relative to the scale's 16px base */
  line-height: calc(1 / 24 * 1em); /* sets the line-height of the icon back to that of it's parent */
  vertical-align: calc((6 / 24 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */
}

.fa-2xl {
  font-size: calc(32 / 16 * 1em); /* converts a 32px size into an em-based value that's relative to the scale's 16px base */
  line-height: calc(1 / 32 * 1em); /* sets the line-height of the icon back to that of it's parent */
  vertical-align: calc((6 / 32 - 0.375) * 1em); /* vertically centers the icon taking into account the surrounding text's descender */
}

.fa-width-auto {
  --fa-width: auto;
}

.fa-fw,
.fa-width-fixed {
  --fa-width: 1.25em;
}

.fa-ul {
  list-style-type: none;
  margin-inline-start: var(--fa-li-margin, 2.5em);
  padding-inline-start: 0;
}
.fa-ul > li {
  position: relative;
}

.fa-li {
  inset-inline-start: calc(-1 * var(--fa-li-width, 2em));
  position: absolute;
  text-align: center;
  width: var(--fa-li-width, 2em);
  line-height: inherit;
}

/* Heads Up: Bordered Icons will not be supported in the future!
  - This feature will be deprecated in the next major release of Font Awesome (v8)!
  - You may continue to use it in this version *v7), but it will not be supported in Font Awesome v8.
*/
/* Notes:
* --@{v.$css-prefix}-border-width = 1/16 by default (to render as ~1px based on a 16px default font-size)
* --@{v.$css-prefix}-border-padding =
  ** 3/16 for vertical padding (to give ~2px of vertical whitespace around an icon considering it's vertical alignment)
  ** 4/16 for horizontal padding (to give ~4px of horizontal whitespace around an icon)
*/
.fa-border {
  border-color: var(--fa-border-color, #eee);
  border-radius: var(--fa-border-radius, 0.1em);
  border-style: var(--fa-border-style, solid);
  border-width: var(--fa-border-width, 0.0625em);
  box-sizing: var(--fa-border-box-sizing, content-box);
  padding: var(--fa-border-padding, 0.1875em 0.25em);
}

.fa-pull-left,
.fa-pull-start {
  float: inline-start;
  margin-inline-end: var(--fa-pull-margin, 0.3em);
}

.fa-pull-right,
.fa-pull-end {
  float: inline-end;
  margin-inline-start: var(--fa-pull-margin, 0.3em);
}

.fa-beat {
  animation-name: fa-beat;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-bounce {
  animation-name: fa-bounce;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
}

.fa-fade {
  animation-name: fa-fade;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-beat-fade {
  animation-name: fa-beat-fade;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-flip {
  animation-name: fa-flip;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-shake {
  animation-name: fa-shake;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin {
  animation-name: fa-spin;
  animation-delay: var(--fa-animation-delay, 0s);
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 2s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin-reverse {
  --fa-animation-direction: reverse;
}

.fa-pulse,
.fa-spin-pulse {
  animation-name: fa-spin;
  animation-direction: var(--fa-animation-direction, normal);
  animation-duration: var(--fa-animation-duration, 1s);
  animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  animation-timing-function: var(--fa-animation-timing, steps(8));
}

@media (prefers-reduced-motion: reduce) {
  .fa-beat,
  .fa-bounce,
  .fa-fade,
  .fa-beat-fade,
  .fa-flip,
  .fa-pulse,
  .fa-shake,
  .fa-spin,
  .fa-spin-pulse {
    animation: none !important;
    transition: none !important;
  }
}
@keyframes fa-beat {
  0%, 90% {
    transform: scale(1);
  }
  45% {
    transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@keyframes fa-bounce {
  0% {
    transform: scale(1, 1) translateY(0);
  }
  10% {
    transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    transform: scale(1, 1) translateY(0);
  }
  100% {
    transform: scale(1, 1) translateY(0);
  }
}
@keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@keyframes fa-flip {
  50% {
    transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@keyframes fa-shake {
  0% {
    transform: rotate(-15deg);
  }
  4% {
    transform: rotate(15deg);
  }
  8%, 24% {
    transform: rotate(-18deg);
  }
  12%, 28% {
    transform: rotate(18deg);
  }
  16% {
    transform: rotate(-22deg);
  }
  20% {
    transform: rotate(22deg);
  }
  32% {
    transform: rotate(-12deg);
  }
  36% {
    transform: rotate(12deg);
  }
  40%, 100% {
    transform: rotate(0deg);
  }
}
@keyframes fa-spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
.fa-rotate-90 {
  transform: rotate(90deg);
}

.fa-rotate-180 {
  transform: rotate(180deg);
}

.fa-rotate-270 {
  transform: rotate(270deg);
}

.fa-flip-horizontal {
  transform: scale(-1, 1);
}

.fa-flip-vertical {
  transform: scale(1, -1);
}

.fa-flip-both,
.fa-flip-horizontal.fa-flip-vertical {
  transform: scale(-1, -1);
}

.fa-rotate-by {
  transform: rotate(var(--fa-rotate-angle, 0));
}

.svg-inline--fa .fa-primary {
  fill: var(--fa-primary-color, currentColor);
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa .fa-secondary {
  fill: var(--fa-secondary-color, currentColor);
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-primary {
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-secondary {
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa mask .fa-primary,
.svg-inline--fa mask .fa-secondary {
  fill: black;
}

.svg-inline--fa.fa-inverse {
  fill: var(--fa-inverse, #fff);
}

.fa-stack {
  display: inline-block;
  height: 2em;
  line-height: 2em;
  position: relative;
  vertical-align: middle;
  width: 2.5em;
}

.fa-inverse {
  color: var(--fa-inverse, #fff);
}

.svg-inline--fa.fa-stack-1x {
  height: 1em;
  width: 1.25em;
}
.svg-inline--fa.fa-stack-2x {
  height: 2em;
  width: 2.5em;
}

.fa-stack-1x,
.fa-stack-2x {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  z-index: var(--fa-stack-z-index, auto);
}`;function Xa(){var e=Ra,t=za,a=g.cssPrefix,r=g.replacementClass,n=ho;if(a!==e||r!==t){var o=new RegExp("\\.".concat(e,"\\-"),"g"),i=new RegExp("\\--".concat(e,"\\-"),"g"),s=new RegExp("\\.".concat(t),"g");n=n.replace(o,".".concat(a,"-")).replace(i,"--".concat(a,"-")).replace(s,".".concat(r))}return n}var Vt=!1;function De(){g.autoAddCss&&!Vt&&(uo(Xa()),Vt=!0)}var yo={mixout:function(){return{dom:{css:Xa,insertCss:De}}},hooks:function(){return{beforeDOMElementCreation:function(){De()},beforeI2svg:function(){De()}}}},H=q||{};H[U]||(H[U]={});H[U].styles||(H[U].styles={});H[U].hooks||(H[U].hooks={});H[U].shims||(H[U].shims=[]);var M=H[U],Ka=[],Ja=function(){C.removeEventListener("DOMContentLoaded",Ja),Ae=1,Ka.map(function(t){return t()})},Ae=!1;G&&(Ae=(C.documentElement.doScroll?/^loaded|^c/:/^loaded|^i|^c/).test(C.readyState),Ae||C.addEventListener("DOMContentLoaded",Ja));function bo(e){G&&(Ae?setTimeout(e,0):Ka.push(e))}function ge(e){var t=e.tag,a=e.attributes,r=a===void 0?{}:a,n=e.children,o=n===void 0?[]:n;return typeof e=="string"?Ga(e):"<".concat(t," ").concat(po(r),">").concat(o.map(ge).join(""),"</").concat(t,">")}function Yt(e,t,a){if(e&&e[t]&&e[t][a])return{prefix:t,iconName:a,icon:e[t][a]}}var Le=function(t,a,r,n){var o=Object.keys(t),i=o.length,s=a,l,c,m;for(r===void 0?(l=1,m=t[o[0]]):(l=0,m=r);l<i;l++)c=o[l],m=s(m,t[c],c,t);return m};function qa(e){return R(e).length!==1?null:e.codePointAt(0).toString(16)}function Ut(e){return Object.keys(e).reduce(function(t,a){var r=e[a],n=!!r.icon;return n?t[r.iconName]=r.icon:t[a]=r,t},{})}function Za(e,t){var a=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{},r=a.skipHooks,n=r===void 0?!1:r,o=Ut(t);typeof M.hooks.addPack=="function"&&!n?M.hooks.addPack(e,Ut(t)):M.styles[e]=f(f({},M.styles[e]||{}),o),e==="fas"&&Za("fa",t)}var me=M.styles,xo=M.shims,Qa=Object.keys(Ya),wo=Qa.reduce(function(e,t){return e[t]=Object.keys(Ya[t]),e},{}),ut=null,er={},tr={},ar={},rr={},nr={};function So(e){return~io.indexOf(e)}function Ao(e,t){var a=t.split("-"),r=a[0],n=a.slice(1).join("-");return r===e&&n!==""&&!So(n)?n:null}var or=function(){var t=function(o){return Le(me,function(i,s,l){return i[l]=Le(s,o,{}),i},{})};er=t(function(n,o,i){if(o[3]&&(n[o[3]]=i),o[2]){var s=o[2].filter(function(l){return typeof l=="number"});s.forEach(function(l){n[l.toString(16)]=i})}return n}),tr=t(function(n,o,i){if(n[i]=i,o[2]){var s=o[2].filter(function(l){return typeof l=="string"});s.forEach(function(l){n[l]=i})}return n}),nr=t(function(n,o,i){var s=o[2];return n[i]=i,s.forEach(function(l){n[l]=i}),n});var a="far"in me||g.autoFetchSvg,r=Le(xo,function(n,o){var i=o[0],s=o[1],l=o[2];return s==="far"&&!a&&(s="fas"),typeof i=="string"&&(n.names[i]={prefix:s,iconName:l}),typeof i=="number"&&(n.unicodes[i.toString(16)]={prefix:s,iconName:l}),n},{names:{},unicodes:{}});ar=r.names,rr=r.unicodes,ut=Ce(g.styleDefault,{family:g.familyDefault})};co(function(e){ut=Ce(e.styleDefault,{family:g.familyDefault})});or();function dt(e,t){return(er[e]||{})[t]}function ko(e,t){return(tr[e]||{})[t]}function ee(e,t){return(nr[e]||{})[t]}function ir(e){return ar[e]||{prefix:null,iconName:null}}function Eo(e){var t=rr[e],a=dt("fas",e);return t||(a?{prefix:"fas",iconName:a}:null)||{prefix:null,iconName:null}}function Z(){return ut}var sr=function(){return{prefix:null,iconName:null,rest:[]}};function Io(e){var t=j,a=Qa.reduce(function(r,n){return r[n]="".concat(g.cssPrefix,"-").concat(n),r},{});return $a.forEach(function(r){(e.includes(a[r])||e.some(function(n){return wo[r].includes(n)}))&&(t=r)}),t}function Ce(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},a=t.family,r=a===void 0?j:a,n=to[r][e];if(r===pe&&!e)return"fad";var o=Wt[r][e]||Wt[r][n],i=e in M.styles?e:null,s=o||i||null;return s}function Po(e){var t=[],a=null;return e.forEach(function(r){var n=Ao(g.cssPrefix,r);n?a=n:r&&t.push(r)}),{iconName:a,rest:t}}function Ht(e){return e.sort().filter(function(t,a,r){return r.indexOf(t)===a})}var Gt=La.concat(Da);function Oe(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},a=t.skipLookups,r=a===void 0?!1:a,n=null,o=Ht(e.filter(function(y){return Gt.includes(y)})),i=Ht(e.filter(function(y){return!Gt.includes(y)})),s=o.filter(function(y){return n=y,!wa.includes(y)}),l=Pe(s,1),c=l[0],m=c===void 0?null:c,p=Io(o),h=f(f({},Po(i)),{},{prefix:Ce(m,{family:p})});return f(f(f({},h),Fo({values:e,family:p,styles:me,config:g,canonical:h,givenPrefix:n})),No(r,n,h))}function No(e,t,a){var r=a.prefix,n=a.iconName;if(e||!r||!n)return{prefix:r,iconName:n};var o=t==="fa"?ir(n):{},i=ee(r,n);return n=o.iconName||i||n,r=o.prefix||r,r==="far"&&!me.far&&me.fas&&!g.autoFetchSvg&&(r="fas"),{prefix:r,iconName:n}}var Co=$a.filter(function(e){return e!==j||e!==pe}),Oo=Object.keys(Be).filter(function(e){return e!==j}).map(function(e){return Object.keys(Be[e])}).flat();function Fo(e){var t=e.values,a=e.family,r=e.canonical,n=e.givenPrefix,o=n===void 0?"":n,i=e.styles,s=i===void 0?{}:i,l=e.config,c=l===void 0?{}:l,m=a===pe,p=t.includes("fa-duotone")||t.includes("fad"),h=c.familyDefault==="duotone",y=r.prefix==="fad"||r.prefix==="fa-duotone";if(!m&&(p||h||y)&&(r.prefix="fad"),(t.includes("fa-brands")||t.includes("fab"))&&(r.prefix="fab"),!r.prefix&&Co.includes(a)){var P=Object.keys(s).find(function(N){return Oo.includes(N)});if(P||c.autoFetchSvg){var w=Zr.get(a).defaultShortPrefixId;r.prefix=w,r.iconName=ee(r.prefix,r.iconName)||r.iconName}}return(r.prefix==="fa"||o==="fa")&&(r.prefix=Z()||"fas"),r}var jo=function(){function e(){Ar(this,e),this.definitions={}}return Er(e,[{key:"add",value:function(){for(var a=this,r=arguments.length,n=new Array(r),o=0;o<r;o++)n[o]=arguments[o];var i=n.reduce(this._pullDefinitions,{});Object.keys(i).forEach(function(s){a.definitions[s]=f(f({},a.definitions[s]||{}),i[s]),Za(s,i[s]),or()})}},{key:"reset",value:function(){this.definitions={}}},{key:"_pullDefinitions",value:function(a,r){var n=r.prefix&&r.iconName&&r.icon?{0:r}:r;return Object.keys(n).map(function(o){var i=n[o],s=i.prefix,l=i.iconName,c=i.icon,m=c[2];a[s]||(a[s]={}),m.length>0&&m.forEach(function(p){typeof p=="string"&&(a[s][p]=c)}),a[s][l]=c}),a}}])}(),Xt=[],ne={},oe={},To=Object.keys(oe);function _o(e,t){var a=t.mixoutsTo;return Xt=e,ne={},Object.keys(oe).forEach(function(r){To.indexOf(r)===-1&&delete oe[r]}),Xt.forEach(function(r){var n=r.mixout?r.mixout():{};if(Object.keys(n).forEach(function(i){typeof n[i]=="function"&&(a[i]=n[i]),Se(n[i])==="object"&&Object.keys(n[i]).forEach(function(s){a[i]||(a[i]={}),a[i][s]=n[i][s]})}),r.hooks){var o=r.hooks();Object.keys(o).forEach(function(i){ne[i]||(ne[i]=[]),ne[i].push(o[i])})}r.provides&&r.provides(oe)}),a}function Xe(e,t){for(var a=arguments.length,r=new Array(a>2?a-2:0),n=2;n<a;n++)r[n-2]=arguments[n];var o=ne[e]||[];return o.forEach(function(i){t=i.apply(null,[t].concat(r))}),t}function ae(e){for(var t=arguments.length,a=new Array(t>1?t-1:0),r=1;r<t;r++)a[r-1]=arguments[r];var n=ne[e]||[];n.forEach(function(o){o.apply(null,a)})}function Q(){var e=arguments[0],t=Array.prototype.slice.call(arguments,1);return oe[e]?oe[e].apply(null,t):void 0}function Ke(e){e.prefix==="fa"&&(e.prefix="fas");var t=e.iconName,a=e.prefix||Z();if(t)return t=ee(a,t)||t,Yt(lr.definitions,a,t)||Yt(M.styles,a,t)}var lr=new jo,$o=function(){g.autoReplaceSvg=!1,g.observeMutations=!1,ae("noAuto")},Do={i2svg:function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};return G?(ae("beforeI2svg",t),Q("pseudoElements2svg",t),Q("i2svg",t)):Promise.reject(new Error("Operation requires a DOM of some kind."))},watch:function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},a=t.autoReplaceSvgRoot;g.autoReplaceSvg===!1&&(g.autoReplaceSvg=!0),g.observeMutations=!0,bo(function(){Mo({autoReplaceSvgRoot:a}),ae("watch",t)})}},Lo={icon:function(t){if(t===null)return null;if(Se(t)==="object"&&t.prefix&&t.iconName)return{prefix:t.prefix,iconName:ee(t.prefix,t.iconName)||t.iconName};if(Array.isArray(t)&&t.length===2){var a=t[1].indexOf("fa-")===0?t[1].slice(3):t[1],r=Ce(t[0]);return{prefix:r,iconName:ee(r,a)||a}}if(typeof t=="string"&&(t.indexOf("".concat(g.cssPrefix,"-"))>-1||t.match(ao))){var n=Oe(t.split(" "),{skipLookups:!0});return{prefix:n.prefix||Z(),iconName:ee(n.prefix,n.iconName)||n.iconName}}if(typeof t=="string"){var o=Z();return{prefix:o,iconName:ee(o,t)||t}}}},L={noAuto:$o,config:g,dom:Do,parse:Lo,library:lr,findIconDefinition:Ke,toHtml:ge},Mo=function(){var t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},a=t.autoReplaceSvgRoot,r=a===void 0?C:a;(Object.keys(M.styles).length>0||g.autoFetchSvg)&&G&&g.autoReplaceSvg&&L.dom.i2svg({node:r})};function Fe(e,t){return Object.defineProperty(e,"abstract",{get:t}),Object.defineProperty(e,"html",{get:function(){return e.abstract.map(function(r){return ge(r)})}}),Object.defineProperty(e,"node",{get:function(){if(G){var r=C.createElement("div");return r.innerHTML=e.html,r.children}}}),e}function Ro(e){var t=e.children,a=e.main,r=e.mask,n=e.attributes,o=e.styles,i=e.transform;if(ct(i)&&a.found&&!r.found){var s=a.width,l=a.height,c={x:s/l/2,y:.5};n.style=Ne(f(f({},o),{},{"transform-origin":"".concat(c.x+i.x/16,"em ").concat(c.y+i.y/16,"em")}))}return[{tag:"svg",attributes:n,children:t}]}function zo(e){var t=e.prefix,a=e.iconName,r=e.children,n=e.attributes,o=e.symbol,i=o===!0?"".concat(t,"-").concat(g.cssPrefix,"-").concat(a):o;return[{tag:"svg",attributes:{style:"display: none;"},children:[{tag:"symbol",attributes:f(f({},n),{},{id:i}),children:r}]}]}function Wo(e){var t=["aria-label","aria-labelledby","title","role"];return t.some(function(a){return a in e})}function mt(e){var t=e.icons,a=t.main,r=t.mask,n=e.prefix,o=e.iconName,i=e.transform,s=e.symbol,l=e.maskId,c=e.extra,m=e.watchable,p=m===void 0?!1:m,h=r.found?r:a,y=h.width,P=h.height,w=[g.replacementClass,o?"".concat(g.cssPrefix,"-").concat(o):""].filter(function(_){return c.classes.indexOf(_)===-1}).filter(function(_){return _!==""||!!_}).concat(c.classes).join(" "),N={children:[],attributes:f(f({},c.attributes),{},{"data-prefix":n,"data-icon":o,class:w,role:c.attributes.role||"img",viewBox:"0 0 ".concat(y," ").concat(P)})};!Wo(c.attributes)&&!c.attributes["aria-hidden"]&&(N.attributes["aria-hidden"]="true"),p&&(N.attributes[te]="");var k=f(f({},N),{},{prefix:n,iconName:o,main:a,mask:r,maskId:l,transform:i,symbol:s,styles:f({},c.styles)}),O=r.found&&a.found?Q("generateAbstractMask",k)||{children:[],attributes:{}}:Q("generateAbstractIcon",k)||{children:[],attributes:{}},F=O.children,z=O.attributes;return k.children=F,k.attributes=z,s?zo(k):Ro(k)}function Kt(e){var t=e.content,a=e.width,r=e.height,n=e.transform,o=e.extra,i=e.watchable,s=i===void 0?!1:i,l=f(f({},o.attributes),{},{class:o.classes.join(" ")});s&&(l[te]="");var c=f({},o.styles);ct(n)&&(c.transform=go({transform:n,startCentered:!0,width:a,height:r}),c["-webkit-transform"]=c.transform);var m=Ne(c);m.length>0&&(l.style=m);var p=[];return p.push({tag:"span",attributes:l,children:[t]}),p}function Bo(e){var t=e.content,a=e.extra,r=f(f({},a.attributes),{},{class:a.classes.join(" ")}),n=Ne(a.styles);n.length>0&&(r.style=n);var o=[];return o.push({tag:"span",attributes:r,children:[t]}),o}var Me=M.styles;function Je(e){var t=e[0],a=e[1],r=e.slice(4),n=Pe(r,1),o=n[0],i=null;return Array.isArray(o)?i={tag:"g",attributes:{class:"".concat(g.cssPrefix,"-").concat($e.GROUP)},children:[{tag:"path",attributes:{class:"".concat(g.cssPrefix,"-").concat($e.SECONDARY),fill:"currentColor",d:o[0]}},{tag:"path",attributes:{class:"".concat(g.cssPrefix,"-").concat($e.PRIMARY),fill:"currentColor",d:o[1]}}]}:i={tag:"path",attributes:{fill:"currentColor",d:o}},{found:!0,width:t,height:a,icon:i}}var Vo={found:!1,width:512,height:512};function Yo(e,t){!Ba&&!g.showMissingIcons&&e&&console.error('Icon with name "'.concat(e,'" and prefix "').concat(t,'" is missing.'))}function qe(e,t){var a=t;return t==="fa"&&g.styleDefault!==null&&(t=Z()),new Promise(function(r,n){if(a==="fa"){var o=ir(e)||{};e=o.iconName||e,t=o.prefix||t}if(e&&t&&Me[t]&&Me[t][e]){var i=Me[t][e];return r(Je(i))}Yo(e,t),r(f(f({},Vo),{},{icon:g.showMissingIcons&&e?Q("missingIconAbstract")||{}:{}}))})}var Jt=function(){},Ze=g.measurePerformance&&he&&he.mark&&he.measure?he:{mark:Jt,measure:Jt},ce='FA "7.0.0"',Uo=function(t){return Ze.mark("".concat(ce," ").concat(t," begins")),function(){return fr(t)}},fr=function(t){Ze.mark("".concat(ce," ").concat(t," ends")),Ze.measure("".concat(ce," ").concat(t),"".concat(ce," ").concat(t," begins"),"".concat(ce," ").concat(t," ends"))},pt={begin:Uo,end:fr},xe=function(){};function qt(e){var t=e.getAttribute?e.getAttribute(te):null;return typeof t=="string"}function Ho(e){var t=e.getAttribute?e.getAttribute(st):null,a=e.getAttribute?e.getAttribute(lt):null;return t&&a}function Go(e){return e&&e.classList&&e.classList.contains&&e.classList.contains(g.replacementClass)}function Xo(){if(g.autoReplaceSvg===!0)return we.replace;var e=we[g.autoReplaceSvg];return e||we.replace}function Ko(e){return C.createElementNS("http://www.w3.org/2000/svg",e)}function Jo(e){return C.createElement(e)}function cr(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},a=t.ceFn,r=a===void 0?e.tag==="svg"?Ko:Jo:a;if(typeof e=="string")return C.createTextNode(e);var n=r(e.tag);Object.keys(e.attributes||[]).forEach(function(i){n.setAttribute(i,e.attributes[i])});var o=e.children||[];return o.forEach(function(i){n.appendChild(cr(i,{ceFn:r}))}),n}function qo(e){var t=" ".concat(e.outerHTML," ");return t="".concat(t,"Font Awesome fontawesome.com "),t}var we={replace:function(t){var a=t[0];if(a.parentNode)if(t[1].forEach(function(n){a.parentNode.insertBefore(cr(n),a)}),a.getAttribute(te)===null&&g.keepOriginalSource){var r=C.createComment(qo(a));a.parentNode.replaceChild(r,a)}else a.remove()},nest:function(t){var a=t[0],r=t[1];if(~ft(a).indexOf(g.replacementClass))return we.replace(t);var n=new RegExp("".concat(g.cssPrefix,"-.*"));if(delete r[0].attributes.id,r[0].attributes.class){var o=r[0].attributes.class.split(" ").reduce(function(s,l){return l===g.replacementClass||l.match(n)?s.toSvg.push(l):s.toNode.push(l),s},{toNode:[],toSvg:[]});r[0].attributes.class=o.toSvg.join(" "),o.toNode.length===0?a.removeAttribute("class"):a.setAttribute("class",o.toNode.join(" "))}var i=r.map(function(s){return ge(s)}).join(`
`);a.setAttribute(te,""),a.innerHTML=i}};function Zt(e){e()}function ur(e,t){var a=typeof t=="function"?t:xe;if(e.length===0)a();else{var r=Zt;g.mutateApproach===Qn&&(r=q.requestAnimationFrame||Zt),r(function(){var n=Xo(),o=pt.begin("mutate");e.map(n),o(),a()})}}var vt=!1;function dr(){vt=!0}function Qe(){vt=!1}var ke=null;function Qt(e){if(Lt&&g.observeMutations){var t=e.treeCallback,a=t===void 0?xe:t,r=e.nodeCallback,n=r===void 0?xe:r,o=e.pseudoElementsCallback,i=o===void 0?xe:o,s=e.observeMutationsRoot,l=s===void 0?C:s;ke=new Lt(function(c){if(!vt){var m=Z();se(c).forEach(function(p){if(p.type==="childList"&&p.addedNodes.length>0&&!qt(p.addedNodes[0])&&(g.searchPseudoElements&&i(p.target),a(p.target)),p.type==="attributes"&&p.target.parentNode&&g.searchPseudoElements&&i([p.target],!0),p.type==="attributes"&&qt(p.target)&&~oo.indexOf(p.attributeName))if(p.attributeName==="class"&&Ho(p.target)){var h=Oe(ft(p.target)),y=h.prefix,P=h.iconName;p.target.setAttribute(st,y||m),P&&p.target.setAttribute(lt,P)}else Go(p.target)&&n(p.target)})}}),G&&ke.observe(l,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}}function Zo(){ke&&ke.disconnect()}function Qo(e){var t=e.getAttribute("style"),a=[];return t&&(a=t.split(";").reduce(function(r,n){var o=n.split(":"),i=o[0],s=o.slice(1);return i&&s.length>0&&(r[i]=s.join(":").trim()),r},{})),a}function ei(e){var t=e.getAttribute("data-prefix"),a=e.getAttribute("data-icon"),r=e.innerText!==void 0?e.innerText.trim():"",n=Oe(ft(e));return n.prefix||(n.prefix=Z()),t&&a&&(n.prefix=t,n.iconName=a),n.iconName&&n.prefix||(n.prefix&&r.length>0&&(n.iconName=ko(n.prefix,e.innerText)||dt(n.prefix,qa(e.innerText))),!n.iconName&&g.autoFetchSvg&&e.firstChild&&e.firstChild.nodeType===Node.TEXT_NODE&&(n.iconName=e.firstChild.data)),n}function ti(e){var t=se(e.attributes).reduce(function(a,r){return a.name!=="class"&&a.name!=="style"&&(a[r.name]=r.value),a},{});return t}function ai(){return{iconName:null,prefix:null,transform:V,symbol:!1,mask:{iconName:null,prefix:null,rest:[]},maskId:null,extra:{classes:[],styles:{},attributes:{}}}}function ea(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{styleParser:!0},a=ei(e),r=a.iconName,n=a.prefix,o=a.rest,i=ti(e),s=Xe("parseNodeAttributes",{},e),l=t.styleParser?Qo(e):[];return f({iconName:r,prefix:n,transform:V,mask:{iconName:null,prefix:null,rest:[]},maskId:null,symbol:!1,extra:{classes:o,styles:l,attributes:i}},s)}var ri=M.styles;function mr(e){var t=g.autoReplaceSvg==="nest"?ea(e,{styleParser:!1}):ea(e);return~t.extra.classes.indexOf(Ua)?Q("generateLayersText",e,t):Q("generateSvgReplacementMutation",e,t)}function ni(){return[].concat(R(Da),R(La))}function ta(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;if(!G)return Promise.resolve();var a=C.documentElement.classList,r=function(p){return a.add("".concat(zt,"-").concat(p))},n=function(p){return a.remove("".concat(zt,"-").concat(p))},o=g.autoFetchSvg?ni():wa.concat(Object.keys(ri));o.includes("fa")||o.push("fa");var i=[".".concat(Ua,":not([").concat(te,"])")].concat(o.map(function(m){return".".concat(m,":not([").concat(te,"])")})).join(", ");if(i.length===0)return Promise.resolve();var s=[];try{s=se(e.querySelectorAll(i))}catch{}if(s.length>0)r("pending"),n("complete");else return Promise.resolve();var l=pt.begin("onTree"),c=s.reduce(function(m,p){try{var h=mr(p);h&&m.push(h)}catch(y){Ba||y.name==="MissingIcon"&&console.error(y)}return m},[]);return new Promise(function(m,p){Promise.all(c).then(function(h){ur(h,function(){r("active"),r("complete"),n("pending"),typeof t=="function"&&t(),l(),m()})}).catch(function(h){l(),p(h)})})}function oi(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;mr(e).then(function(a){a&&ur([a],t)})}function ii(e){return function(t){var a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=(t||{}).icon?t:Ke(t||{}),n=a.mask;return n&&(n=(n||{}).icon?n:Ke(n||{})),e(r,f(f({},a),{},{mask:n}))}}var si=function(t){var a=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=a.transform,n=r===void 0?V:r,o=a.symbol,i=o===void 0?!1:o,s=a.mask,l=s===void 0?null:s,c=a.maskId,m=c===void 0?null:c,p=a.classes,h=p===void 0?[]:p,y=a.attributes,P=y===void 0?{}:y,w=a.styles,N=w===void 0?{}:w;if(t){var k=t.prefix,O=t.iconName,F=t.icon;return Fe(f({type:"icon"},t),function(){return ae("beforeDOMElementCreation",{iconDefinition:t,params:a}),mt({icons:{main:Je(F),mask:l?Je(l.icon):{found:!1,width:null,height:null,icon:{}}},prefix:k,iconName:O,transform:f(f({},V),n),symbol:i,maskId:m,extra:{attributes:P,styles:N,classes:h}})})}},li={mixout:function(){return{icon:ii(si)}},hooks:function(){return{mutationObserverCallbacks:function(a){return a.treeCallback=ta,a.nodeCallback=oi,a}}},provides:function(t){t.i2svg=function(a){var r=a.node,n=r===void 0?C:r,o=a.callback,i=o===void 0?function(){}:o;return ta(n,i)},t.generateSvgReplacementMutation=function(a,r){var n=r.iconName,o=r.prefix,i=r.transform,s=r.symbol,l=r.mask,c=r.maskId,m=r.extra;return new Promise(function(p,h){Promise.all([qe(n,o),l.iconName?qe(l.iconName,l.prefix):Promise.resolve({found:!1,width:512,height:512,icon:{}})]).then(function(y){var P=Pe(y,2),w=P[0],N=P[1];p([a,mt({icons:{main:w,mask:N},prefix:o,iconName:n,transform:i,symbol:s,maskId:c,extra:m,watchable:!0})])}).catch(h)})},t.generateAbstractIcon=function(a){var r=a.children,n=a.attributes,o=a.main,i=a.transform,s=a.styles,l=Ne(s);l.length>0&&(n.style=l);var c;return ct(i)&&(c=Q("generateAbstractTransformGrouping",{main:o,transform:i,containerWidth:o.width,iconWidth:o.width})),r.push(c||o.icon),{children:r,attributes:n}}}},fi={mixout:function(){return{layer:function(a){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=r.classes,o=n===void 0?[]:n;return Fe({type:"layer"},function(){ae("beforeDOMElementCreation",{assembler:a,params:r});var i=[];return a(function(s){Array.isArray(s)?s.map(function(l){i=i.concat(l.abstract)}):i=i.concat(s.abstract)}),[{tag:"span",attributes:{class:["".concat(g.cssPrefix,"-layers")].concat(R(o)).join(" ")},children:i}]})}}}},ci={mixout:function(){return{counter:function(a){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=r.title,o=n===void 0?null:n,i=r.classes,s=i===void 0?[]:i,l=r.attributes,c=l===void 0?{}:l,m=r.styles,p=m===void 0?{}:m;return Fe({type:"counter",content:a},function(){return ae("beforeDOMElementCreation",{content:a,params:r}),Bo({content:a.toString(),title:o,extra:{attributes:c,styles:p,classes:["".concat(g.cssPrefix,"-layers-counter")].concat(R(s))}})})}}}},ui={mixout:function(){return{text:function(a){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=r.transform,o=n===void 0?V:n,i=r.classes,s=i===void 0?[]:i,l=r.attributes,c=l===void 0?{}:l,m=r.styles,p=m===void 0?{}:m;return Fe({type:"text",content:a},function(){return ae("beforeDOMElementCreation",{content:a,params:r}),Kt({content:a,transform:f(f({},V),o),extra:{attributes:c,styles:p,classes:["".concat(g.cssPrefix,"-layers-text")].concat(R(s))}})})}}},provides:function(t){t.generateLayersText=function(a,r){var n=r.transform,o=r.extra,i=null,s=null;if(ba){var l=parseInt(getComputedStyle(a).fontSize,10),c=a.getBoundingClientRect();i=c.width/l,s=c.height/l}return Promise.resolve([a,Kt({content:a.innerHTML,width:i,height:s,transform:n,extra:o,watchable:!0})])}}},pr=new RegExp('"',"ug"),aa=[1105920,1112319],ra=f(f(f(f({},{FontAwesome:{normal:"fas",400:"fas"}}),qr),qn),sn),et=Object.keys(ra).reduce(function(e,t){return e[t.toLowerCase()]=ra[t],e},{}),di=Object.keys(et).reduce(function(e,t){var a=et[t];return e[t]=a[900]||R(Object.entries(a))[0][1],e},{});function mi(e){var t=e.replace(pr,"");return qa(R(t)[0]||"")}function pi(e){var t=e.getPropertyValue("font-feature-settings").includes("ss01"),a=e.getPropertyValue("content"),r=a.replace(pr,""),n=r.codePointAt(0),o=n>=aa[0]&&n<=aa[1],i=r.length===2?r[0]===r[1]:!1;return o||i||t}function vi(e,t){var a=e.replace(/^['"]|['"]$/g,"").toLowerCase(),r=parseInt(t),n=isNaN(r)?"normal":r;return(et[a]||{})[n]||di[a]}function na(e,t){var a="".concat(Zn).concat(t.replace(":","-"));return new Promise(function(r,n){if(e.getAttribute(a)!==null)return r();var o=se(e.children),i=o.filter(function(Y){return Y.getAttribute(Ye)===t})[0],s=q.getComputedStyle(e,t),l=s.getPropertyValue("font-family"),c=l.match(ro),m=s.getPropertyValue("font-weight"),p=s.getPropertyValue("content");if(i&&!c)return e.removeChild(i),r();if(c&&p!=="none"&&p!==""){var h=s.getPropertyValue("content"),y=vi(l,m),P=mi(h),w=c[0].startsWith("FontAwesome"),N=pi(s),k=dt(y,P),O=k;if(w){var F=Eo(P);F.iconName&&F.prefix&&(k=F.iconName,y=F.prefix)}if(k&&!N&&(!i||i.getAttribute(st)!==y||i.getAttribute(lt)!==O)){e.setAttribute(a,O),i&&e.removeChild(i);var z=ai(),_=z.extra;_.attributes[Ye]=t,qe(k,y).then(function(Y){var re=mt(f(f({},z),{},{icons:{main:Y,mask:sr()},prefix:y,iconName:O,extra:_,watchable:!0})),T=C.createElementNS("http://www.w3.org/2000/svg","svg");t==="::before"?e.insertBefore(T,e.firstChild):e.appendChild(T),T.outerHTML=re.map(function(je){return ge(je)}).join(`
`),e.removeAttribute(a),r()}).catch(n)}else r()}else r()})}function gi(e){return Promise.all([na(e,"::before"),na(e,"::after")])}function hi(e){return e.parentNode!==document.head&&!~eo.indexOf(e.tagName.toUpperCase())&&!e.getAttribute(Ye)&&(!e.parentNode||e.parentNode.tagName!=="svg")}var yi=function(t){return!!t&&Wa.some(function(a){return t.includes(a)})},bi=function(t){if(!t)return[];for(var a=new Set,r=[t],n=[/(?=\s:)/,new RegExp("(?<=\\)\\)?[^,]*,)")],o=function(){var y=s[i];r=r.flatMap(function(P){return P.split(y).map(function(w){return w.replace(/,\s*$/,"").trim()})})},i=0,s=n;i<s.length;i++)o();r=r.flatMap(function(h){return h.includes("(")?h:h.split(",").map(function(y){return y.trim()})});var l=be(r),c;try{for(l.s();!(c=l.n()).done;){var m=c.value;if(yi(m)){var p=Wa.reduce(function(h,y){return h.replace(y,"")},m);p!==""&&p!=="*"&&a.add(p)}}}catch(h){l.e(h)}finally{l.f()}return a};function oa(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!1;if(G){var a;if(t)a=e;else if(g.searchPseudoElementsFullScan)a=e.querySelectorAll("*");else{var r=new Set,n=be(document.styleSheets),o;try{for(n.s();!(o=n.n()).done;){var i=o.value;try{var s=be(i.cssRules),l;try{for(s.s();!(l=s.n()).done;){var c=l.value,m=bi(c.selectorText),p=be(m),h;try{for(p.s();!(h=p.n()).done;){var y=h.value;r.add(y)}}catch(w){p.e(w)}finally{p.f()}}}catch(w){s.e(w)}finally{s.f()}}catch(w){g.searchPseudoElementsWarnings&&console.warn("Font Awesome: cannot parse stylesheet: ".concat(i.href," (").concat(w.message,`)
If it declares any Font Awesome CSS pseudo-elements, they will not be rendered as SVG icons. Add crossorigin="anonymous" to the <link>, enable searchPseudoElementsFullScan for slower but more thorough DOM parsing, or suppress this warning by setting searchPseudoElementsWarnings to false.`))}}}catch(w){n.e(w)}finally{n.f()}if(!r.size)return;var P=Array.from(r).join(", ");try{a=e.querySelectorAll(P)}catch{}}return new Promise(function(w,N){var k=se(a).filter(hi).map(gi),O=pt.begin("searchPseudoElements");dr(),Promise.all(k).then(function(){O(),Qe(),w()}).catch(function(){O(),Qe(),N()})})}}var xi={hooks:function(){return{mutationObserverCallbacks:function(a){return a.pseudoElementsCallback=oa,a}}},provides:function(t){t.pseudoElements2svg=function(a){var r=a.node,n=r===void 0?C:r;g.searchPseudoElements&&oa(n)}}},ia=!1,wi={mixout:function(){return{dom:{unwatch:function(){dr(),ia=!0}}}},hooks:function(){return{bootstrap:function(){Qt(Xe("mutationObserverCallbacks",{}))},noAuto:function(){Zo()},watch:function(a){var r=a.observeMutationsRoot;ia?Qe():Qt(Xe("mutationObserverCallbacks",{observeMutationsRoot:r}))}}}},sa=function(t){var a={size:16,x:0,y:0,flipX:!1,flipY:!1,rotate:0};return t.toLowerCase().split(" ").reduce(function(r,n){var o=n.toLowerCase().split("-"),i=o[0],s=o.slice(1).join("-");if(i&&s==="h")return r.flipX=!0,r;if(i&&s==="v")return r.flipY=!0,r;if(s=parseFloat(s),isNaN(s))return r;switch(i){case"grow":r.size=r.size+s;break;case"shrink":r.size=r.size-s;break;case"left":r.x=r.x-s;break;case"right":r.x=r.x+s;break;case"up":r.y=r.y-s;break;case"down":r.y=r.y+s;break;case"rotate":r.rotate=r.rotate+s;break}return r},a)},Si={mixout:function(){return{parse:{transform:function(a){return sa(a)}}}},hooks:function(){return{parseNodeAttributes:function(a,r){var n=r.getAttribute("data-fa-transform");return n&&(a.transform=sa(n)),a}}},provides:function(t){t.generateAbstractTransformGrouping=function(a){var r=a.main,n=a.transform,o=a.containerWidth,i=a.iconWidth,s={transform:"translate(".concat(o/2," 256)")},l="translate(".concat(n.x*32,", ").concat(n.y*32,") "),c="scale(".concat(n.size/16*(n.flipX?-1:1),", ").concat(n.size/16*(n.flipY?-1:1),") "),m="rotate(".concat(n.rotate," 0 0)"),p={transform:"".concat(l," ").concat(c," ").concat(m)},h={transform:"translate(".concat(i/2*-1," -256)")},y={outer:s,inner:p,path:h};return{tag:"g",attributes:f({},y.outer),children:[{tag:"g",attributes:f({},y.inner),children:[{tag:r.icon.tag,children:r.icon.children,attributes:f(f({},r.icon.attributes),y.path)}]}]}}}},Re={x:0,y:0,width:"100%",height:"100%"};function la(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!0;return e.attributes&&(e.attributes.fill||t)&&(e.attributes.fill="black"),e}function Ai(e){return e.tag==="g"?e.children:[e]}var ki={hooks:function(){return{parseNodeAttributes:function(a,r){var n=r.getAttribute("data-fa-mask"),o=n?Oe(n.split(" ").map(function(i){return i.trim()})):sr();return o.prefix||(o.prefix=Z()),a.mask=o,a.maskId=r.getAttribute("data-fa-mask-id"),a}}},provides:function(t){t.generateAbstractMask=function(a){var r=a.children,n=a.attributes,o=a.main,i=a.mask,s=a.maskId,l=a.transform,c=o.width,m=o.icon,p=i.width,h=i.icon,y=vo({transform:l,containerWidth:p,iconWidth:c}),P={tag:"rect",attributes:f(f({},Re),{},{fill:"white"})},w=m.children?{children:m.children.map(la)}:{},N={tag:"g",attributes:f({},y.inner),children:[la(f({tag:m.tag,attributes:f(f({},m.attributes),y.path)},w))]},k={tag:"g",attributes:f({},y.outer),children:[N]},O="mask-".concat(s||Bt()),F="clip-".concat(s||Bt()),z={tag:"mask",attributes:f(f({},Re),{},{id:O,maskUnits:"userSpaceOnUse",maskContentUnits:"userSpaceOnUse"}),children:[P,k]},_={tag:"defs",children:[{tag:"clipPath",attributes:{id:F},children:Ai(h)},z]};return r.push(_,{tag:"rect",attributes:f({fill:"currentColor","clip-path":"url(#".concat(F,")"),mask:"url(#".concat(O,")")},Re)}),{children:r,attributes:n}}}},Ei={provides:function(t){var a=!1;q.matchMedia&&(a=q.matchMedia("(prefers-reduced-motion: reduce)").matches),t.missingIconAbstract=function(){var r=[],n={fill:"currentColor"},o={attributeType:"XML",repeatCount:"indefinite",dur:"2s"};r.push({tag:"path",attributes:f(f({},n),{},{d:"M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z"})});var i=f(f({},o),{},{attributeName:"opacity"}),s={tag:"circle",attributes:f(f({},n),{},{cx:"256",cy:"364",r:"28"}),children:[]};return a||s.children.push({tag:"animate",attributes:f(f({},o),{},{attributeName:"r",values:"28;14;28;28;14;28;"})},{tag:"animate",attributes:f(f({},i),{},{values:"1;0;1;1;0;1;"})}),r.push(s),r.push({tag:"path",attributes:f(f({},n),{},{opacity:"1",d:"M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"}),children:a?[]:[{tag:"animate",attributes:f(f({},i),{},{values:"1;0;0;0;0;1;"})}]}),a||r.push({tag:"path",attributes:f(f({},n),{},{opacity:"0",d:"M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"}),children:[{tag:"animate",attributes:f(f({},i),{},{values:"0;0;1;1;0;0;"})}]}),{tag:"g",attributes:{class:"missing"},children:r}}}},Ii={hooks:function(){return{parseNodeAttributes:function(a,r){var n=r.getAttribute("data-fa-symbol"),o=n===null?!1:n===""?!0:n;return a.symbol=o,a}}}},Pi=[yo,li,fi,ci,ui,xi,wi,Si,ki,Ei,Ii];_o(Pi,{mixoutsTo:L});L.noAuto;L.config;L.library;L.dom;var tt=L.parse;L.findIconDefinition;L.toHtml;var Ni=L.icon;L.layer;L.text;L.counter;var Ci={};function at(e,t){(t==null||t>e.length)&&(t=e.length);for(var a=0,r=Array(t);a<t;a++)r[a]=e[a];return r}function Oi(e){if(Array.isArray(e))return e}function Fi(e){if(Array.isArray(e))return at(e)}function J(e,t,a){return(t=Ri(t))in e?Object.defineProperty(e,t,{value:a,enumerable:!0,configurable:!0,writable:!0}):e[t]=a,e}function ji(e){if(typeof Symbol<"u"&&e[Symbol.iterator]!=null||e["@@iterator"]!=null)return Array.from(e)}function Ti(e,t){var a=e==null?null:typeof Symbol<"u"&&e[Symbol.iterator]||e["@@iterator"];if(a!=null){var r,n,o,i,s=[],l=!0,c=!1;try{if(o=(a=a.call(e)).next,t!==0)for(;!(l=(r=o.call(a)).done)&&(s.push(r.value),s.length!==t);l=!0);}catch(m){c=!0,n=m}finally{try{if(!l&&a.return!=null&&(i=a.return(),Object(i)!==i))return}finally{if(c)throw n}}return s}}function _i(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function $i(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function fa(e,t){var a=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(n){return Object.getOwnPropertyDescriptor(e,n).enumerable})),a.push.apply(a,r)}return a}function B(e){for(var t=1;t<arguments.length;t++){var a=arguments[t]!=null?arguments[t]:{};t%2?fa(Object(a),!0).forEach(function(r){J(e,r,a[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(a)):fa(Object(a)).forEach(function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(a,r))})}return e}function Di(e,t){if(e==null)return{};var a,r,n=Li(e,t);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(e);for(r=0;r<o.length;r++)a=o[r],t.indexOf(a)===-1&&{}.propertyIsEnumerable.call(e,a)&&(n[a]=e[a])}return n}function Li(e,t){if(e==null)return{};var a={};for(var r in e)if({}.hasOwnProperty.call(e,r)){if(t.indexOf(r)!==-1)continue;a[r]=e[r]}return a}function ca(e,t){return Oi(e)||Ti(e,t)||vr(e,t)||_i()}function rt(e){return Fi(e)||ji(e)||vr(e)||$i()}function Mi(e,t){if(typeof e!="object"||!e)return e;var a=e[Symbol.toPrimitive];if(a!==void 0){var r=a.call(e,t||"default");if(typeof r!="object")return r;throw new TypeError("@@toPrimitive must return a primitive value.")}return(t==="string"?String:Number)(e)}function Ri(e){var t=Mi(e,"string");return typeof t=="symbol"?t:t+""}function Ee(e){"@babel/helpers - typeof";return Ee=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(t){return typeof t}:function(t){return t&&typeof Symbol=="function"&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},Ee(e)}function vr(e,t){if(e){if(typeof e=="string")return at(e,t);var a={}.toString.call(e).slice(8,-1);return a==="Object"&&e.constructor&&(a=e.constructor.name),a==="Map"||a==="Set"?Array.from(e):a==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a)?at(e,t):void 0}}var zi="7.0.0-alpha1",nt;try{var Wi=require("@fortawesome/fontawesome-svg-core/package.json");nt=Wi.version}catch{nt=Ci.FA_VERSION||"7.0.0-alpha8"}function Bi(e){var t=e.beat,a=e.fade,r=e.beatFade,n=e.bounce,o=e.shake,i=e.flash,s=e.spin,l=e.spinPulse,c=e.spinReverse,m=e.pulse,p=e.fixedWidth,h=e.inverse,y=e.border,P=e.listItem,w=e.flip,N=e.size,k=e.rotation,O=e.pull,F=e.swapOpacity,z=e.rotateBy,_=e.widthAuto,Y=Vi(nt,zi),re=J(J(J(J(J(J({"fa-beat":t,"fa-fade":a,"fa-beat-fade":r,"fa-bounce":n,"fa-shake":o,"fa-flash":i,"fa-spin":s,"fa-spin-reverse":c,"fa-spin-pulse":l,"fa-pulse":m,"fa-fw":p,"fa-inverse":h,"fa-border":y,"fa-li":P,"fa-flip":w===!0,"fa-flip-horizontal":w==="horizontal"||w==="both","fa-flip-vertical":w==="vertical"||w==="both"},"fa-".concat(N),typeof N<"u"&&N!==null),"fa-rotate-".concat(k),typeof k<"u"&&k!==null&&k!==0),"fa-pull-".concat(O),typeof O<"u"&&O!==null),"fa-swap-opacity",F),"fa-rotate-by",Y&&z),"fa-width-auto",Y&&_);return Object.keys(re).map(function(T){return re[T]?T:null}).filter(function(T){return T})}function Vi(e,t){for(var a=e.split("-"),r=ca(a,2),n=r[0],o=r[1],i=t.split("-"),s=ca(i,2),l=s[0],c=s[1],m=n.split("."),p=l.split("."),h=0;h<Math.max(m.length,p.length);h++){var y=m[h]||"0",P=p[h]||"0",w=parseInt(y,10),N=parseInt(P,10);if(w!==N)return w>N}for(var k=0;k<Math.max(m.length,p.length);k++){var O=m[k]||"0",F=p[k]||"0";if(O!==F&&O.length!==F.length)return O.length<F.length}return!(o&&!c)}function Yi(e){return e=e-0,e===e}function gr(e){return Yi(e)?e:(e=e.replace(/[\-_\s]+(.)?/g,function(t,a){return a?a.toUpperCase():""}),e.substr(0,1).toLowerCase()+e.substr(1))}var Ui=["style"];function Hi(e){return e.charAt(0).toUpperCase()+e.slice(1)}function Gi(e){return e.split(";").map(function(t){return t.trim()}).filter(function(t){return t}).reduce(function(t,a){var r=a.indexOf(":"),n=gr(a.slice(0,r)),o=a.slice(r+1).trim();return n.startsWith("webkit")?t[Hi(n)]=o:t[n]=o,t},{})}function hr(e,t){var a=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};if(typeof t=="string")return t;var r=(t.children||[]).map(function(l){return hr(e,l)}),n=Object.keys(t.attributes||{}).reduce(function(l,c){var m=t.attributes[c];switch(c){case"class":l.attrs.className=m,delete t.attributes.class;break;case"style":l.attrs.style=Gi(m);break;default:c.indexOf("aria-")===0||c.indexOf("data-")===0?l.attrs[c.toLowerCase()]=m:l.attrs[gr(c)]=m}return l},{attrs:{}}),o=a.style,i=o===void 0?{}:o,s=Di(a,Ui);return n.attrs.style=B(B({},n.attrs.style),i),e.apply(void 0,[t.tag,B(B({},n.attrs),s)].concat(rt(r)))}var yr=!1;try{yr=!0}catch{}function Xi(){if(!yr&&console&&typeof console.error=="function"){var e;(e=console).error.apply(e,arguments)}}function ua(e){if(e&&Ee(e)==="object"&&e.prefix&&e.iconName&&e.icon)return e;if(tt.icon)return tt.icon(e);if(e===null)return null;if(e&&Ee(e)==="object"&&e.prefix&&e.iconName)return e;if(Array.isArray(e)&&e.length===2)return{prefix:e[0],iconName:e[1]};if(typeof e=="string")return{prefix:"fas",iconName:e}}function ze(e,t){return Array.isArray(t)&&t.length>0||!Array.isArray(t)&&t?J({},e,t):{}}var da={border:!1,className:"",mask:null,maskId:null,fixedWidth:!1,inverse:!1,flip:!1,icon:null,listItem:!1,pull:null,pulse:!1,rotation:null,rotateBy:!1,size:null,spin:!1,spinPulse:!1,spinReverse:!1,beat:!1,fade:!1,beatFade:!1,bounce:!1,shake:!1,symbol:!1,title:"",titleId:null,transform:null,swapOpacity:!1,widthAuto:!1},Ie=pa.forwardRef(function(e,t){var a=B(B({},da),e),r=a.icon,n=a.mask,o=a.symbol,i=a.className,s=a.title,l=a.titleId,c=a.maskId,m=ua(r),p=ze("classes",[].concat(rt(Bi(a)),rt((i||"").split(" ")))),h=ze("transform",typeof a.transform=="string"?tt.transform(a.transform):a.transform),y=ze("mask",ua(n)),P=Ni(m,B(B(B(B({},p),h),y),{},{symbol:o,title:s,titleId:l,maskId:c}));if(!P)return Xi("Could not find icon",m),null;var w=P.abstract,N={ref:t};return Object.keys(a).forEach(function(k){da.hasOwnProperty(k)||(N[k]=a[k])}),Ki(w[0],N)});Ie.displayName="FontAwesomeIcon";Ie.propTypes={beat:x.bool,border:x.bool,beatFade:x.bool,bounce:x.bool,className:x.string,fade:x.bool,flash:x.bool,mask:x.oneOfType([x.object,x.array,x.string]),maskId:x.string,fixedWidth:x.bool,inverse:x.bool,flip:x.oneOf([!0,!1,"horizontal","vertical","both"]),icon:x.oneOfType([x.object,x.array,x.string]),listItem:x.bool,pull:x.oneOf(["right","left"]),pulse:x.bool,rotation:x.oneOf([0,90,180,270]),rotateBy:x.bool,shake:x.bool,size:x.oneOf(["2xs","xs","sm","lg","xl","2xl","1x","2x","3x","4x","5x","6x","7x","8x","9x","10x"]),spin:x.bool,spinPulse:x.bool,spinReverse:x.bool,symbol:x.oneOfType([x.bool,x.string]),title:x.string,titleId:x.string,transform:x.oneOfType([x.string,x.object]),swapOpacity:x.bool,widthAuto:x.bool};var Ki=hr.bind(null,pa.createElement);/*!
 * Font Awesome Free 7.0.0 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
 * Copyright 2025 Fonticons, Inc.
 */var Ji={prefix:"fas",iconName:"expand",icon:[448,512,[],"f065","M32 32C14.3 32 0 46.3 0 64l0 96c0 17.7 14.3 32 32 32s32-14.3 32-32l0-64 64 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 32zM64 352c0-17.7-14.3-32-32-32S0 334.3 0 352l0 96c0 17.7 14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0 0-64zM320 32c-17.7 0-32 14.3-32 32s14.3 32 32 32l64 0 0 64c0 17.7 14.3 32 32 32s32-14.3 32-32l0-96c0-17.7-14.3-32-32-32l-96 0zM448 352c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 64-64 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l96 0c17.7 0 32-14.3 32-32l0-96z"]},qi={prefix:"fas",iconName:"compress",icon:[448,512,[],"f066","M160 64c0-17.7-14.3-32-32-32S96 46.3 96 64l0 64-64 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l96 0c17.7 0 32-14.3 32-32l0-96zM32 320c-17.7 0-32 14.3-32 32s14.3 32 32 32l64 0 0 64c0 17.7 14.3 32 32 32s32-14.3 32-32l0-96c0-17.7-14.3-32-32-32l-96 0zM352 64c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 96c0 17.7 14.3 32 32 32l96 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-64 0 0-64zM320 320c-17.7 0-32 14.3-32 32l0 96c0 17.7 14.3 32 32 32s32-14.3 32-32l0-64 64 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-96 0z"]},Zi={prefix:"fas",iconName:"location-dot",icon:[384,512,["map-marker-alt"],"f3c5","M0 188.6C0 84.4 86 0 192 0S384 84.4 384 188.6c0 119.3-120.2 262.3-170.4 316.8-11.8 12.8-31.5 12.8-43.3 0-50.2-54.5-170.4-197.5-170.4-316.8zM192 256a64 64 0 1 0 0-128 64 64 0 1 0 0 128z"]};const ma=`
    .permanent-label {
        background-color: transparent !important;
        border: none !important;
        box-shadow: none !important;
        font-weight: bold;
        color: #333;
        text-shadow: -1px -1px 0 #fff, 1px -1px 0 #fff, -1px 1px 0 #fff, 1px 1px 0 #fff;
        font-size: 14px;
    }
`;function ts({onRegionClick:e}){const t=W.useRef(null),a=W.useRef(null),r=W.useRef(null),[n,o]=W.useState("state"),[i,s]=W.useState(null),[l,c]=W.useState([]),[m,p]=W.useState(!1),[h,y]=W.useState(null),P=()=>{const v=document.documentElement;m?document.exitFullscreen?document.exitFullscreen():document.webkitExitFullscreen?document.webkitExitFullscreen():document.msExitFullscreen&&document.msExitFullscreen():v.requestFullscreen?v.requestFullscreen():v.webkitRequestFullscreen?v.webkitRequestFullscreen():v.msRequestFullscreen&&v.msRequestFullscreen(),p(!m)},w=()=>{a.current&&a.current.locate({setView:!0,maxZoom:16})};W.useEffect(()=>{const v=()=>{p(!!document.fullscreenElement)};return document.addEventListener("fullscreenchange",v),document.addEventListener("webkitfullscreenchange",v),document.addEventListener("mozfullscreenchange",v),document.addEventListener("MSFullscreenChange",v),()=>{document.removeEventListener("fullscreenchange",v),document.removeEventListener("webkitfullscreenchange",v),document.removeEventListener("mozfullscreenchange",v),document.removeEventListener("MSFullscreenChange",v)}},[]),W.useEffect(()=>{const v=document.createElement("style");if(v.textContent=ma,document.head.appendChild(v),!a.current&&t.current){a.current=X.map(t.current).setView([23.4707,77.9455],6),fetch("/india.geojson").then(u=>u.json()).then(u=>{X.geoJSON(u,{style:{color:"#003366",weight:1,fillOpacity:.07,fillColor:"#e0e0e0"},interactive:!1}).addTo(a.current)}).catch(u=>{console.error("Could not load India GeoJSON:",u)}),a.current.on("locationfound",u=>{y(u.latlng),r.current||X.marker(u.latlng).addTo(a.current).bindPopup("You are here!").openPopup()}),a.current.on("locationerror",u=>{alert("Could not access your location. Please check your location permissions.")});const b=X.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:18}).addTo(a.current),d=X.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",{maxZoom:18}),E={"Street Map":b,"Satellite View":d};X.control.layers(E).addTo(a.current),O()}return()=>{a.current&&(a.current.remove(),a.current=null);const b=document.querySelector("style");b&&b.textContent===ma&&document.head.removeChild(b)}},[]);const N=()=>{r.current&&(a.current.removeLayer(r.current),r.current=null)},k={bhopal:[{id:"BPL01",name:"Bhopal",pcNo:"18"},{id:"BPL02",name:"Vidisha",pcNo:"19"},{id:"BPL03",name:"Rajgarh",pcNo:"20"}],indore:[{id:"IND01",name:"Indore",pcNo:"25"},{id:"IND02",name:"Dhar",pcNo:"24"}]},O=async()=>{try{const v=await fetch("http://localhost:5000/api/state-polygons");if(!v.ok)throw new Error("Failed to fetch state data");const b=await v.json();if(b.success&&b.data&&b.data.length>0){const d=b.data[0],E={...d,features:d.features.map(u=>!u.geometry||u.geometry.type!=="MultiPolygon"||!Array.isArray(u.geometry.coordinates)||!Array.isArray(u.geometry.coordinates[0])||!Array.isArray(u.geometry.coordinates[0][0])?u:{...u,properties:{...u.properties,id:u.properties.Name.toLowerCase().replace(/\s+/g,"-"),name:u.properties.Name}})};T(E,"state"),o("state"),s(null)}else alert("No state data available")}catch(v){console.error("Error loading state data:",v)}},F=async v=>{try{const b=await fetch("http://localhost:5000/api/division-polygons");if(!b.ok)throw new Error("Failed to fetch division data");const d=await b.json();if(d.features&&d.features.length>0){const E=d.features.reduce((S,I)=>{var le,fe;const $=(le=I.properties.DIVISION_NAME||I.properties.DIVISION_NAME)==null?void 0:le.toUpperCase();return S[$]?(S[$].properties.districts.add(I.properties.District),S[$].properties.parliaments.add(I.properties.Parliament),S[$].properties.vsCodes.add(I.properties.VS_Code)):S[$]={type:"Feature",properties:{id:$.toLowerCase().replace(/\s+/g,"-"),name:$,DIVISION_CODE:I.properties.DIVISION_CODE,ST_NAME:I.properties.ST_NAME,districts:new Set([I.properties.District]),parliaments:new Set([I.properties.Parliament]),vsCodes:new Set([I.properties.VS_Code])},geometry:{type:"MultiPolygon",coordinates:[]}},(fe=I.geometry)!=null&&fe.coordinates&&(I.geometry.type==="MultiPolygon"?S[$].geometry.coordinates.push(...I.geometry.coordinates):I.geometry.type==="Polygon"&&S[$].geometry.coordinates.push([I.geometry.coordinates])),S},{}),u={type:"FeatureCollection",features:Object.values(E).map(S=>({...S,properties:{...S.properties,districts:Array.from(S.properties.districts),parliaments:Array.from(S.properties.parliaments),vsCodes:Array.from(S.properties.vsCodes),parliamentarySeats:S.properties.parliaments.size}}))};T(u,"division")}else console.warn("No division data available")}catch(b){console.error("Error loading division data:",b)}},z=async v=>{try{const d=await fetch(`http://localhost:5000/api/parliament-polygons/name/${v}`);if(!d.ok)throw new Error("Failed to fetch parliamentary data");const E=await d.json();if(E&&E.length>0&&E[0].features){const S={type:"FeatureCollection",features:E[0].features.map(I=>({type:"Feature",properties:{id:I.properties.PC_NAME.toLowerCase().replace(/\s+/g,"-"),name:I.properties.PC_NAME,pcNo:I.properties.PC_NO,stateCode:I.properties.ST_CODE,stateName:I.properties.ST_NAME,parliamentId:I.properties.PC_ID,divisionName:v},geometry:I.geometry}))};S.features.length>0?T(S,"parliamentary"):alert("No parliamentary constituencies found for division: "+v)}else alert("No parliamentary data available")}catch(b){console.error("Error loading parliamentary data:",b)}},_=async v=>{try{const b=await fetch(`http://localhost:5000/api/assembly-polygons/parliament/${v}`);if(!b.ok)throw new Error("Failed to fetch assembly data");const d=await b.json();if(d&&d.data[0].type==="FeatureCollection"&&d.data[0].features&&d.data[0].features.length>0){const E={type:"FeatureCollection",features:d.data[0].features.map(u=>({type:"Feature",properties:{id:u.properties.PC_ID.toString(),name:u.properties.AC_NAME,acNo:u.properties.AC_NO.toString(),pcName:u.properties.PC_NAME,district:u.properties.ST_NAME,division:u.properties.DIVISION_NAME,category:"GEN",lastElectionYear:"2023"},geometry:u.geometry}))};T(E,"assembly")}else alert("No assembly data available"),o("assembly")}catch(b){console.error("Error loading assembly data:",b)}},Y=async v=>{try{const b=await fetch(`http://localhost:5000/api/block-polygons/booth/${v}`);if(!b.ok)throw new Error("Failed to fetch block data");const d=await b.json();if(d.success&&d.data&&d.data.length>0){const E={type:"FeatureCollection",features:d.data[0].features.map(u=>({type:"Feature",properties:{...u.properties,id:u.properties.BlockName.toLowerCase().replace(/\s+/g,"-"),name:u.properties.BlockName,blockCode:u.properties.BlockName,acName:u.properties.AC_NAME,mainTown:u.properties.DIST_NAME,population:null,totalVoters:null,totalBooths:1,ruralBooths:u.properties.BoothName?1:0,urbanBooths:0},geometry:u.geometry}))};T(E,"block")}else alert("No block data available for this assembly constituency")}catch(b){console.error("Error loading block data:",b)}},re=async v=>{try{const b=await fetch(`http://localhost:5000/api/booth-polygons/block-number/${v}`);if(!b.ok)throw new Error(`HTTP error! status: ${b.status}`);const d=await b.json();if(!d.success||!d.features||!Array.isArray(d.features))throw new Error("Invalid API response structure");if(d.features.length===0){alert(`No booths found for block ${v}`);return}const E={type:"FeatureCollection",features:d.features.map((u,S)=>{var I,$,le,fe,gt,ht,yt,bt,xt,wt,St,At,kt,Et,It,Pt,Nt,Ct,Ot,Ft,jt;return!u.geometry||!u.geometry.coordinates?(console.warn(`Feature ${S} missing geometry`,u),null):{type:"Feature",properties:{id:((I=u.properties)==null?void 0:I.BoothId)||(($=u.properties)==null?void 0:$.id)||`booth-${v}-${S}`,name:((le=u.properties)==null?void 0:le.BoothName)||((fe=u.properties)==null?void 0:fe.name)||`Booth ${((gt=u.properties)==null?void 0:gt.BoothNo)||S}`,boothNo:((ht=u.properties)==null?void 0:ht.BoothNo)||((yt=u.properties)==null?void 0:yt.boothNo)||"",blockName:((bt=u.properties)==null?void 0:bt.BlockName)||((xt=u.properties)==null?void 0:xt.blockName)||"",blockNumber:((wt=u.properties)==null?void 0:wt.BlockNumber)||v,location:((St=u.properties)==null?void 0:St.Location)||((At=u.properties)==null?void 0:At.location)||"",totalVoters:parseInt(((kt=u.properties)==null?void 0:kt.TotalVoters)||((Et=u.properties)==null?void 0:Et.totalVoters)||0),maleFemaleRatio:((It=u.properties)==null?void 0:It.Gender_Ratio)||((Pt=u.properties)==null?void 0:Pt.maleFemaleRatio)||"",boothArea:((Nt=u.properties)==null?void 0:Nt.Area_Type)||((Ct=u.properties)==null?void 0:Ct.boothArea)||"",lastTurnout:((Ot=u.properties)==null?void 0:Ot.Last_Turnout)||((Ft=u.properties)==null?void 0:Ft.lastTurnout)||"",facilities:Array.isArray((jt=u.properties)==null?void 0:jt.Facilities)?u.properties.Facilities:[]},geometry:u.geometry}}).filter(u=>u!==null)};a.current.eachLayer(u=>{u instanceof X.Marker&&u._popup&&u._popup._content.includes("Booth")&&a.current.removeLayer(u)}),T(E,"booth"),o("booth"),r.current&&a.current.fitBounds(r.current.getBounds(),{padding:[50,50],maxZoom:16})}catch(b){console.error("Error in loadBoothData:",b),alert(`Failed to load booth data: ${b.message}`),i&&i.properties&&Y(i.properties.blockCode||i.properties.id)}},T=(v,b)=>{N();const d=E=>{let u="#477fcdff",S=2,I=.2;return b==="state"?(S=3,I=.15,E.properties.Name==="Madhya Pradesh"&&(S=4)):b==="division"&&(S=4),{color:u,weight:S,fillOpacity:I,fillColor:u}};r.current=X.geoJSON(v,{style:d,onEachFeature:(E,u)=>{u.bindTooltip(E.properties.name||"",{permanent:!0,direction:"center",className:"permanent-label",offset:[0,0],opacity:.9});const S=br(E,b);u.bindPopup(S),u.on("click",()=>je(E,b)),u.on({mouseover:I=>{I.target.setStyle({weight:3,color:"#666",fillOpacity:.3})},mouseout:I=>{r.current.resetStyle(I.target)}})}}).addTo(a.current),a.current.fitBounds(r.current.getBounds())},je=(v,b)=>{switch(c(d=>[...d,{level:n,feature:i,id:v.properties.id,name:v.properties.name}]),s(v),e&&e({id:v.properties.id,name:v.properties.name,level:b}),b){case"state":F(v.properties.id),o("division");break;case"division":const d=v.properties.name?v.properties.name:null;d?(z(d),o("parliamentary")):console.warn("No Parliament found for division:",v.properties.name);break;case"parliamentary":_(v.properties.pcNo),o("assembly");break;case"assembly":Y(v.properties.acNo),o("block");break;case"block":const E=v.properties.BlockNumber||v.properties.BlockNumber;E?(re(E),o("booth")):console.warn("No Block number found in feature properties:",v.properties);break}},br=(v,b)=>{const d=v.properties;let E=`<div>
            <h4 style="margin: 0 0 10px 0; color: #333;">${d.Name||d.name||""}</h4>`;switch(b){case"state":E+=`
                    <p><strong>State Name:</strong> ${d.Name||""}</p>
                    <p><strong>Type:</strong> ${d.Type||""}</p>
                    <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #eee;">
                        <p style="font-size: 0.9em; color: #666;">Click to view Divisions</p>
                    </div>`;break;case"division":const u=d.districts?d.districts.join(", "):"";E+=`
                    <p><strong>Division Code:</strong> ${d.DIVISION_CODE||""}</p>
                    <p><strong>State:</strong> ${d.ST_NAME||""}</p>
                    <p><strong>Districts:</strong> ${u}</p>
                    ${d.DIVISION_CODE&&k[d.id]?`<p><strong>Parliamentary Constituencies:</strong></p>
                        <ul style="margin: 5px 0; padding-left: 20px;">
                            ${k[d.id].map(S=>`<li>${S.name} (PC No: ${S.pcNo})</li>`).join("")}
                        </ul>`:""}`;break;case"parliamentary":E+=`
                    <p><strong>Parliamentary Constituency:</strong> ${d.name||""}</p>
                    <p><strong>Division:</strong> ${d.divisionName||""}</p>
                    <p><strong>District:</strong> ${d.district||""}</p>
                    <p><strong>Assembly Name:</strong> ${d.assemblyName||""}</p>
                    <p><strong>Assembly Seats:</strong> ${d.assemblySeats||""}</p>
                    <p><strong>VS Code:</strong> ${d.vsCode||""}</p>
                    <p><strong>Last Election Year:</strong> ${d.lastElectionYear||""}</p>
                    <hr style="margin: 10px 0">
                    <p style="font-size: 0.9em; color: #666;">Click to view Assembly Constituencies</p>`;break;case"assembly":E+=`
                    <p><strong>AC No:</strong> ${d.acNo||""}</p>
                    <p><strong>Parliamentary:</strong> ${d.pcName||""}</p>
                    <p><strong>Category:</strong> ${d.category||""}</p>
                    <p><strong>Total Voters:</strong> ${d.totalVoters?Number(d.totalVoters).toLocaleString():""}</p>
                    <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #eee;">
                        <p><strong>Last Election (${d.lastElectionYear||""}):</strong></p>
                        <p>Winner: ${d.winner||""}</p>
                        <p>Margin: ${d.margin?Number(d.margin).toLocaleString():""} votes</p>
                    </div>
                    <hr style="margin: 10px 0">
                    <p style="font-size: 0.9em; color: #666;">Click to view Blocks</p>`;break;case"block":E+=`
                    <p><strong>Block Code:</strong> ${d.blockCode||""}</p>
                    <p><strong>Assembly:</strong> ${d.acName||""}</p>
                    <p><strong>Main Town:</strong> ${d.mainTown||""}</p>
                    <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #eee;">
                        <p><strong>Demographics:</strong></p>
                        <p>Population: ${d.population?Number(d.population).toLocaleString():""}</p>
                        <p>Total Voters: ${d.totalVoters?Number(d.totalVoters).toLocaleString():""}</p>
                    </div>
                    <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #eee;">
                        <p><strong>Booth Information:</strong></p>
                        <p>Total Booths: ${d.totalBooths||""}</p>
                        <p>Rural Booths: ${d.ruralBooths||""}</p>
                        <p>Urban Booths: ${d.urbanBooths||""}</p>
                    </div>
                    <hr style="margin: 10px 0">
                    <p style="font-size: 0.9em; color: #666;">Click to view Booths</p>`;break;case"booth":E+=`
                    <p><strong>Booth No:</strong> ${d.boothNo||""}</p>
                    <p><strong>Block:</strong> ${d.blockName||""}</p>
                    <p><strong>Location:</strong> ${d.location||""}</p>
                    <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #eee;">
                        <p><strong>Voter Information:</strong></p>
                        <p>Total Voters: ${d.totalVoters?Number(d.totalVoters).toLocaleString():""}</p>
                        <p>Male/Female Ratio: ${d.maleFemaleRatio||""}</p>
                        <p>Last Turnout: ${d.lastTurnout||""}</p>
                    </div>
                    <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #eee;">
                        <p><strong>Area Type:</strong> ${d.boothArea||""}</p>
                        <p><strong>Available Facilities:</strong></p>
                        <ul style="margin: 5px 0; padding-left: 20px;">
                            ${d.facilities?d.facilities.map(S=>`<li>${S}</li>`).join(""):""}
                        </ul>
                    </div>`;break}return E+="</div>",E};return D.jsx(xr,{children:D.jsxs("div",{children:[D.jsxs("div",{style:{position:"relative"},children:[D.jsx("div",{style:{height:"600px",position:"relative"},className:"map-container",ref:t}),D.jsxs("div",{style:{position:"absolute",top:"10px",right:"10px",display:"flex",flexDirection:"column",gap:"10px",zIndex:1e3},children:[D.jsx("button",{onClick:w,style:{padding:"8px",backgroundColor:"white",border:"2px solid rgba(0,0,0,0.2)",borderRadius:"4px",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",width:"34px",height:"34px"},title:"Find my location",children:D.jsx(Ie,{icon:Zi})}),D.jsx("button",{onClick:P,style:{padding:"8px",backgroundColor:"white",border:"2px solid rgba(0,0,0,0.2)",borderRadius:"4px",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",width:"34px",height:"34px"},title:m?"Exit fullscreen":"Enter fullscreen",children:D.jsx(Ie,{icon:m?qi:Ji})})]})]}),D.jsx("div",{style:{padding:"10px",background:"#f5f5f5",marginTop:"10px"},children:D.jsx("div",{style:{display:"flex",flexDirection:"column",gap:"10px"},children:i&&D.jsx("div",{style:{padding:"8px",backgroundColor:"#fff",borderRadius:"4px",boxShadow:"0 1px 3px rgba(0,0,0,0.1)"},children:D.jsxs("span",{style:{fontWeight:"500"},children:["Current Location: ",i.properties.name," (",n,")"]})})})})]})})}export{ts as default};
