const e="/election/assets/empty-4cc5uIhA.png",t="/election/assets/empty-4cc5uIhA.png";export{e as a,t as i};
