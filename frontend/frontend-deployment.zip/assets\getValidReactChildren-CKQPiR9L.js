import{r}from"./index-Ba4Gy4r-.js";function a(t){return r.Children.toArray(t).filter(e=>r.isValidElement(e))}export{a as g};
