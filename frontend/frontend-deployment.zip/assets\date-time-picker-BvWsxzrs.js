import{aR as Q,bi as Y,bj as y,j as e,b1 as m,c1 as q,r as v,P as n,cu as R,dz as G,dA as $,dB as h,dC as u,dD as B,dE as c,dF as Z,dG as U,dH as K,dI as ee,l as f,S as g,b2 as p,B as k,t as D,i as M,G as C}from"./index-Ba4Gy4r-.js";import{C as ae,a as te,b as ne}from"./ComponentSkeleton-z_9Iszgd.js";import{u as re,D as ie,a as oe}from"./DesktopDatePicker-DfCIjotd.js";import{t as se,w as le,q as de,r as S,s as ue,v as ce,Z as me,_ as he,X as pe}from"./dateViewRenderers-44VAGNu6.js";import{M as ge,D as T}from"./DatePicker-JRbq7gx6.js";import{T as j,a as ve}from"./TimePicker-CA3C738o.js";import{D as W}from"./DateTimePicker-DvOVid1c.js";import{T as fe,a as ye}from"./ToggleButtonGroup-ClkAL1cd.js";import"./Skeleton-CsVZ7OH8.js";import"./useDesktopPicker-CO5NQHFi.js";import"./useMobilePicker-BIx7EDEK.js";import"./MobileDateTimePicker-DxyGIQd7.js";import"./getValidReactChildren-CKQPiR9L.js";const be=["props","ref"],Pe=Q(se)(({theme:r})=>({overflow:"hidden",minWidth:le,backgroundColor:(r.vars||r).palette.background.paper})),xe=r=>{var t;let{props:i,ref:a}=r,o=Y(r,be);const{localeText:s,slots:d,slotProps:l,className:x,sx:b,displayStaticWrapperAs:w,autoFocus:F}=i,{layoutProps:E,renderCurrentView:X}=de(y({},o,{props:i,autoFocusView:F??!1,additionalViewProps:{},wrapperVariant:w})),_=(t=d==null?void 0:d.layout)!=null?t:Pe;return{renderPicker:()=>{var z,A,L;return e.jsx(m,{localeText:s,children:e.jsx(_,y({},E,l==null?void 0:l.layout,{slots:d,slotProps:l,sx:[...Array.isArray(b)?b:[b],...Array.isArray(l==null||(z=l.layout)==null?void 0:z.sx)?l.layout.sx:[l==null||(A=l.layout)==null?void 0:A.sx]],className:q(x,l==null||(L=l.layout)==null?void 0:L.className),ref:a,children:X()}))})}}},P=v.forwardRef(function(t,i){var a,o,s;const d=re(t,"MuiStaticDatePicker"),l=(a=d.displayStaticWrapperAs)!=null?a:"mobile",x=y({day:S,month:S,year:S},d.viewRenderers),b=y({},d,{viewRenderers:x,displayStaticWrapperAs:l,yearsPerRow:(o=d.yearsPerRow)!=null?o:l==="mobile"?3:4,slotProps:y({},d.slotProps,{toolbar:y({hidden:l==="desktop"},(s=d.slotProps)==null?void 0:s.toolbar)})}),{renderPicker:w}=xe({props:b,valueManager:ue,valueType:"date",validator:ce,ref:i});return w()});P.propTypes={autoFocus:n.bool,className:n.string,components:n.object,componentsProps:n.object,dayOfWeekFormatter:n.func,defaultCalendarMonth:n.any,defaultValue:n.any,disabled:n.bool,disableFuture:n.bool,disableHighlightToday:n.bool,disablePast:n.bool,displayStaticWrapperAs:n.oneOf(["desktop","mobile"]),displayWeekNumber:n.bool,fixedWeekNumber:n.number,loading:n.bool,localeText:n.object,maxDate:n.any,minDate:n.any,monthsPerRow:n.oneOf([3,4]),onAccept:n.func,onChange:n.func,onClose:n.func,onError:n.func,onMonthChange:n.func,onViewChange:n.func,onYearChange:n.func,openTo:n.oneOf(["day","month","year"]),orientation:n.oneOf(["landscape","portrait"]),readOnly:n.bool,reduceAnimations:n.bool,referenceDate:n.any,renderLoading:n.func,shouldDisableDate:n.func,shouldDisableMonth:n.func,shouldDisableYear:n.func,showDaysOutsideCurrentMonth:n.bool,slotProps:n.object,slots:n.object,sx:n.oneOfType([n.arrayOf(n.oneOfType([n.func,n.object,n.bool])),n.func,n.object]),timezone:n.string,value:n.any,view:n.oneOf(["day","month","year"]),viewRenderers:n.shape({day:n.func,month:n.func,year:n.func}),views:n.arrayOf(n.oneOf(["day","month","year"]).isRequired),yearsPerRow:n.oneOf([3,4])};function we(r){R(1,arguments);var t=G(r),i=t.getDay();return i===0||i===6}function ke(r,t,i){R(2,arguments);var a=$(r,i),o=$(t,i);return a.getTime()===o.getTime()}var O={lessThanXSeconds:{standalone:{one:"weniger als 1 Sekunde",other:"weniger als {{count}} Sekunden"},withPreposition:{one:"weniger als 1 Sekunde",other:"weniger als {{count}} Sekunden"}},xSeconds:{standalone:{one:"1 Sekunde",other:"{{count}} Sekunden"},withPreposition:{one:"1 Sekunde",other:"{{count}} Sekunden"}},halfAMinute:{standalone:"halbe Minute",withPreposition:"halben Minute"},lessThanXMinutes:{standalone:{one:"weniger als 1 Minute",other:"weniger als {{count}} Minuten"},withPreposition:{one:"weniger als 1 Minute",other:"weniger als {{count}} Minuten"}},xMinutes:{standalone:{one:"1 Minute",other:"{{count}} Minuten"},withPreposition:{one:"1 Minute",other:"{{count}} Minuten"}},aboutXHours:{standalone:{one:"etwa 1 Stunde",other:"etwa {{count}} Stunden"},withPreposition:{one:"etwa 1 Stunde",other:"etwa {{count}} Stunden"}},xHours:{standalone:{one:"1 Stunde",other:"{{count}} Stunden"},withPreposition:{one:"1 Stunde",other:"{{count}} Stunden"}},xDays:{standalone:{one:"1 Tag",other:"{{count}} Tage"},withPreposition:{one:"1 Tag",other:"{{count}} Tagen"}},aboutXWeeks:{standalone:{one:"etwa 1 Woche",other:"etwa {{count}} Wochen"},withPreposition:{one:"etwa 1 Woche",other:"etwa {{count}} Wochen"}},xWeeks:{standalone:{one:"1 Woche",other:"{{count}} Wochen"},withPreposition:{one:"1 Woche",other:"{{count}} Wochen"}},aboutXMonths:{standalone:{one:"etwa 1 Monat",other:"etwa {{count}} Monate"},withPreposition:{one:"etwa 1 Monat",other:"etwa {{count}} Monaten"}},xMonths:{standalone:{one:"1 Monat",other:"{{count}} Monate"},withPreposition:{one:"1 Monat",other:"{{count}} Monaten"}},aboutXYears:{standalone:{one:"etwa 1 Jahr",other:"etwa {{count}} Jahre"},withPreposition:{one:"etwa 1 Jahr",other:"etwa {{count}} Jahren"}},xYears:{standalone:{one:"1 Jahr",other:"{{count}} Jahre"},withPreposition:{one:"1 Jahr",other:"{{count}} Jahren"}},overXYears:{standalone:{one:"mehr als 1 Jahr",other:"mehr als {{count}} Jahre"},withPreposition:{one:"mehr als 1 Jahr",other:"mehr als {{count}} Jahren"}},almostXYears:{standalone:{one:"fast 1 Jahr",other:"fast {{count}} Jahre"},withPreposition:{one:"fast 1 Jahr",other:"fast {{count}} Jahren"}}},De=function(t,i,a){var o,s=a!=null&&a.addSuffix?O[t].withPreposition:O[t].standalone;return typeof s=="string"?o=s:i===1?o=s.one:o=s.other.replace("{{count}}",String(i)),a!=null&&a.addSuffix?a.comparison&&a.comparison>0?"in "+o:"vor "+o:o},Me={full:"EEEE, do MMMM y",long:"do MMMM y",medium:"do MMM y",short:"dd.MM.y"},Ce={full:"HH:mm:ss zzzz",long:"HH:mm:ss z",medium:"HH:mm:ss",short:"HH:mm"},Se={full:"{{date}} 'um' {{time}}",long:"{{date}} 'um' {{time}}",medium:"{{date}} {{time}}",short:"{{date}} {{time}}"},Te={date:h({formats:Me,defaultWidth:"full"}),time:h({formats:Ce,defaultWidth:"full"}),dateTime:h({formats:Se,defaultWidth:"full"})},je={lastWeek:"'letzten' eeee 'um' p",yesterday:"'gestern um' p",today:"'heute um' p",tomorrow:"'morgen um' p",nextWeek:"eeee 'um' p",other:"P"},We=function(t,i,a,o){return je[t]},Ve={narrow:["v.Chr.","n.Chr."],abbreviated:["v.Chr.","n.Chr."],wide:["vor Christus","nach Christus"]},Fe={narrow:["1","2","3","4"],abbreviated:["Q1","Q2","Q3","Q4"],wide:["1. Quartal","2. Quartal","3. Quartal","4. Quartal"]},V={narrow:["J","F","M","A","M","J","J","A","S","O","N","D"],abbreviated:["Jan","Feb","Mär","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"],wide:["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"]},ze={narrow:V.narrow,abbreviated:["Jan.","Feb.","März","Apr.","Mai","Juni","Juli","Aug.","Sep.","Okt.","Nov.","Dez."],wide:V.wide},Ae={narrow:["S","M","D","M","D","F","S"],short:["So","Mo","Di","Mi","Do","Fr","Sa"],abbreviated:["So.","Mo.","Di.","Mi.","Do.","Fr.","Sa."],wide:["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"]},Le={narrow:{am:"vm.",pm:"nm.",midnight:"Mitternacht",noon:"Mittag",morning:"Morgen",afternoon:"Nachm.",evening:"Abend",night:"Nacht"},abbreviated:{am:"vorm.",pm:"nachm.",midnight:"Mitternacht",noon:"Mittag",morning:"Morgen",afternoon:"Nachmittag",evening:"Abend",night:"Nacht"},wide:{am:"vormittags",pm:"nachmittags",midnight:"Mitternacht",noon:"Mittag",morning:"Morgen",afternoon:"Nachmittag",evening:"Abend",night:"Nacht"}},$e={narrow:{am:"vm.",pm:"nm.",midnight:"Mitternacht",noon:"Mittag",morning:"morgens",afternoon:"nachm.",evening:"abends",night:"nachts"},abbreviated:{am:"vorm.",pm:"nachm.",midnight:"Mitternacht",noon:"Mittag",morning:"morgens",afternoon:"nachmittags",evening:"abends",night:"nachts"},wide:{am:"vormittags",pm:"nachmittags",midnight:"Mitternacht",noon:"Mittag",morning:"morgens",afternoon:"nachmittags",evening:"abends",night:"nachts"}},Oe=function(t){var i=Number(t);return i+"."},Ne={ordinalNumber:Oe,era:u({values:Ve,defaultWidth:"wide"}),quarter:u({values:Fe,defaultWidth:"wide",argumentCallback:function(t){return t-1}}),month:u({values:V,formattingValues:ze,defaultWidth:"wide"}),day:u({values:Ae,defaultWidth:"wide"}),dayPeriod:u({values:Le,defaultWidth:"wide",formattingValues:$e,defaultFormattingWidth:"wide"})},Ie=/^(\d+)(\.)?/i,He=/\d+/i,Je={narrow:/^(v\.? ?Chr\.?|n\.? ?Chr\.?)/i,abbreviated:/^(v\.? ?Chr\.?|n\.? ?Chr\.?)/i,wide:/^(vor Christus|vor unserer Zeitrechnung|nach Christus|unserer Zeitrechnung)/i},Re={any:[/^v/i,/^n/i]},Be={narrow:/^[1234]/i,abbreviated:/^q[1234]/i,wide:/^[1234](\.)? Quartal/i},Ee={any:[/1/i,/2/i,/3/i,/4/i]},Xe={narrow:/^[jfmasond]/i,abbreviated:/^(j[aä]n|feb|mär[z]?|apr|mai|jun[i]?|jul[i]?|aug|sep|okt|nov|dez)\.?/i,wide:/^(januar|februar|märz|april|mai|juni|juli|august|september|oktober|november|dezember)/i},_e={narrow:[/^j/i,/^f/i,/^m/i,/^a/i,/^m/i,/^j/i,/^j/i,/^a/i,/^s/i,/^o/i,/^n/i,/^d/i],any:[/^j[aä]/i,/^f/i,/^mär/i,/^ap/i,/^mai/i,/^jun/i,/^jul/i,/^au/i,/^s/i,/^o/i,/^n/i,/^d/i]},Qe={narrow:/^[smdmf]/i,short:/^(so|mo|di|mi|do|fr|sa)/i,abbreviated:/^(son?|mon?|die?|mit?|don?|fre?|sam?)\.?/i,wide:/^(sonntag|montag|dienstag|mittwoch|donnerstag|freitag|samstag)/i},Ye={any:[/^so/i,/^mo/i,/^di/i,/^mi/i,/^do/i,/^f/i,/^sa/i]},qe={narrow:/^(vm\.?|nm\.?|Mitternacht|Mittag|morgens|nachm\.?|abends|nachts)/i,abbreviated:/^(vorm\.?|nachm\.?|Mitternacht|Mittag|morgens|nachm\.?|abends|nachts)/i,wide:/^(vormittags|nachmittags|Mitternacht|Mittag|morgens|nachmittags|abends|nachts)/i},Ge={any:{am:/^v/i,pm:/^n/i,midnight:/^Mitte/i,noon:/^Mitta/i,morning:/morgens/i,afternoon:/nachmittags/i,evening:/abends/i,night:/nachts/i}},Ze={ordinalNumber:B({matchPattern:Ie,parsePattern:He,valueCallback:function(t){return parseInt(t)}}),era:c({matchPatterns:Je,defaultMatchWidth:"wide",parsePatterns:Re,defaultParseWidth:"any"}),quarter:c({matchPatterns:Be,defaultMatchWidth:"wide",parsePatterns:Ee,defaultParseWidth:"any",valueCallback:function(t){return t+1}}),month:c({matchPatterns:Xe,defaultMatchWidth:"wide",parsePatterns:_e,defaultParseWidth:"any"}),day:c({matchPatterns:Qe,defaultMatchWidth:"wide",parsePatterns:Ye,defaultParseWidth:"any"}),dayPeriod:c({matchPatterns:qe,defaultMatchWidth:"wide",parsePatterns:Ge,defaultParseWidth:"any"})},Ue={code:"de",formatDistance:De,formatLong:Te,formatRelative:We,localize:Ne,match:Ze,options:{weekStartsOn:1,firstWeekContainsDate:4}},Ke={full:"EEEE, d MMMM yyyy",long:"d MMMM yyyy",medium:"d MMM yyyy",short:"dd/MM/yyyy"},ea={full:"HH:mm:ss zzzz",long:"HH:mm:ss z",medium:"HH:mm:ss",short:"HH:mm"},aa={full:"{{date}} 'at' {{time}}",long:"{{date}} 'at' {{time}}",medium:"{{date}}, {{time}}",short:"{{date}}, {{time}}"},ta={date:h({formats:Ke,defaultWidth:"full"}),time:h({formats:ea,defaultWidth:"full"}),dateTime:h({formats:aa,defaultWidth:"full"})},na={code:"en-GB",formatDistance:Z,formatLong:ta,formatRelative:U,localize:K,match:ee,options:{weekStartsOn:1,firstWeekContainsDate:4}},ra={lessThanXSeconds:{one:"不到 1 秒",other:"不到 {{count}} 秒"},xSeconds:{one:"1 秒",other:"{{count}} 秒"},halfAMinute:"半分钟",lessThanXMinutes:{one:"不到 1 分钟",other:"不到 {{count}} 分钟"},xMinutes:{one:"1 分钟",other:"{{count}} 分钟"},xHours:{one:"1 小时",other:"{{count}} 小时"},aboutXHours:{one:"大约 1 小时",other:"大约 {{count}} 小时"},xDays:{one:"1 天",other:"{{count}} 天"},aboutXWeeks:{one:"大约 1 个星期",other:"大约 {{count}} 个星期"},xWeeks:{one:"1 个星期",other:"{{count}} 个星期"},aboutXMonths:{one:"大约 1 个月",other:"大约 {{count}} 个月"},xMonths:{one:"1 个月",other:"{{count}} 个月"},aboutXYears:{one:"大约 1 年",other:"大约 {{count}} 年"},xYears:{one:"1 年",other:"{{count}} 年"},overXYears:{one:"超过 1 年",other:"超过 {{count}} 年"},almostXYears:{one:"将近 1 年",other:"将近 {{count}} 年"}},ia=function(t,i,a){var o,s=ra[t];return typeof s=="string"?o=s:i===1?o=s.one:o=s.other.replace("{{count}}",String(i)),a!=null&&a.addSuffix?a.comparison&&a.comparison>0?o+"内":o+"前":o},oa={full:"y'年'M'月'd'日' EEEE",long:"y'年'M'月'd'日'",medium:"yyyy-MM-dd",short:"yy-MM-dd"},sa={full:"zzzz a h:mm:ss",long:"z a h:mm:ss",medium:"a h:mm:ss",short:"a h:mm"},la={full:"{{date}} {{time}}",long:"{{date}} {{time}}",medium:"{{date}} {{time}}",short:"{{date}} {{time}}"},da={date:h({formats:oa,defaultWidth:"full"}),time:h({formats:sa,defaultWidth:"full"}),dateTime:h({formats:la,defaultWidth:"full"})};function N(r,t,i){var a="eeee p";return ke(r,t,i)?a:r.getTime()>t.getTime()?"'下个'"+a:"'上个'"+a}var ua={lastWeek:N,yesterday:"'昨天' p",today:"'今天' p",tomorrow:"'明天' p",nextWeek:N,other:"PP p"},ca=function(t,i,a,o){var s=ua[t];return typeof s=="function"?s(i,a,o):s},ma={narrow:["前","公元"],abbreviated:["前","公元"],wide:["公元前","公元"]},ha={narrow:["1","2","3","4"],abbreviated:["第一季","第二季","第三季","第四季"],wide:["第一季度","第二季度","第三季度","第四季度"]},pa={narrow:["一","二","三","四","五","六","七","八","九","十","十一","十二"],abbreviated:["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"],wide:["一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"]},ga={narrow:["日","一","二","三","四","五","六"],short:["日","一","二","三","四","五","六"],abbreviated:["周日","周一","周二","周三","周四","周五","周六"],wide:["星期日","星期一","星期二","星期三","星期四","星期五","星期六"]},va={narrow:{am:"上",pm:"下",midnight:"凌晨",noon:"午",morning:"早",afternoon:"下午",evening:"晚",night:"夜"},abbreviated:{am:"上午",pm:"下午",midnight:"凌晨",noon:"中午",morning:"早晨",afternoon:"中午",evening:"晚上",night:"夜间"},wide:{am:"上午",pm:"下午",midnight:"凌晨",noon:"中午",morning:"早晨",afternoon:"中午",evening:"晚上",night:"夜间"}},fa={narrow:{am:"上",pm:"下",midnight:"凌晨",noon:"午",morning:"早",afternoon:"下午",evening:"晚",night:"夜"},abbreviated:{am:"上午",pm:"下午",midnight:"凌晨",noon:"中午",morning:"早晨",afternoon:"中午",evening:"晚上",night:"夜间"},wide:{am:"上午",pm:"下午",midnight:"凌晨",noon:"中午",morning:"早晨",afternoon:"中午",evening:"晚上",night:"夜间"}},ya=function(t,i){var a=Number(t);switch(i==null?void 0:i.unit){case"date":return a.toString()+"日";case"hour":return a.toString()+"时";case"minute":return a.toString()+"分";case"second":return a.toString()+"秒";default:return"第 "+a.toString()}},ba={ordinalNumber:ya,era:u({values:ma,defaultWidth:"wide"}),quarter:u({values:ha,defaultWidth:"wide",argumentCallback:function(t){return t-1}}),month:u({values:pa,defaultWidth:"wide"}),day:u({values:ga,defaultWidth:"wide"}),dayPeriod:u({values:va,defaultWidth:"wide",formattingValues:fa,defaultFormattingWidth:"wide"})},Pa=/^(第\s*)?\d+(日|时|分|秒)?/i,xa=/\d+/i,wa={narrow:/^(前)/i,abbreviated:/^(前)/i,wide:/^(公元前|公元)/i},ka={any:[/^(前)/i,/^(公元)/i]},Da={narrow:/^[1234]/i,abbreviated:/^第[一二三四]刻/i,wide:/^第[一二三四]刻钟/i},Ma={any:[/(1|一)/i,/(2|二)/i,/(3|三)/i,/(4|四)/i]},Ca={narrow:/^(一|二|三|四|五|六|七|八|九|十[二一])/i,abbreviated:/^(一|二|三|四|五|六|七|八|九|十[二一]|\d|1[12])月/i,wide:/^(一|二|三|四|五|六|七|八|九|十[二一])月/i},Sa={narrow:[/^一/i,/^二/i,/^三/i,/^四/i,/^五/i,/^六/i,/^七/i,/^八/i,/^九/i,/^十(?!(一|二))/i,/^十一/i,/^十二/i],any:[/^一|1/i,/^二|2/i,/^三|3/i,/^四|4/i,/^五|5/i,/^六|6/i,/^七|7/i,/^八|8/i,/^九|9/i,/^十(?!(一|二))|10/i,/^十一|11/i,/^十二|12/i]},Ta={narrow:/^[一二三四五六日]/i,short:/^[一二三四五六日]/i,abbreviated:/^周[一二三四五六日]/i,wide:/^星期[一二三四五六日]/i},ja={any:[/日/i,/一/i,/二/i,/三/i,/四/i,/五/i,/六/i]},Wa={any:/^(上午?|下午?|午夜|[中正]午|早上?|下午|晚上?|凌晨|)/i},Va={any:{am:/^上午?/i,pm:/^下午?/i,midnight:/^午夜/i,noon:/^[中正]午/i,morning:/^早上/i,afternoon:/^下午/i,evening:/^晚上?/i,night:/^凌晨/i}},Fa={ordinalNumber:B({matchPattern:Pa,parsePattern:xa,valueCallback:function(t){return parseInt(t,10)}}),era:c({matchPatterns:wa,defaultMatchWidth:"wide",parsePatterns:ka,defaultParseWidth:"any"}),quarter:c({matchPatterns:Da,defaultMatchWidth:"wide",parsePatterns:Ma,defaultParseWidth:"any",valueCallback:function(t){return t+1}}),month:c({matchPatterns:Ca,defaultMatchWidth:"wide",parsePatterns:Sa,defaultParseWidth:"any"}),day:c({matchPatterns:Ta,defaultMatchWidth:"wide",parsePatterns:ja,defaultParseWidth:"any"}),dayPeriod:c({matchPatterns:Wa,defaultMatchWidth:"any",parsePatterns:Va,defaultParseWidth:"any"})},za={code:"zh-CN",formatDistance:ia,formatLong:da,formatRelative:ca,localize:ba,match:Fa,options:{weekStartsOn:1,firstWeekContainsDate:4}};function Aa(){const[r,t]=v.useState(new Date);return e.jsx(f,{title:"Static Mode",codeHighlight:!0,codeString:`<LocalizationProvider dateAdapter={AdapterDateFns}>
  <StaticDatePicker
    displayStaticWrapperAs="desktop"
    openTo="year"
    value={value}
    onChange={(newValue) => {
      setValue(newValue);
    }}
    renderInput={(params) => <TextField {...params} />}
  />
</LocalizationProvider>
<LocalizationProvider dateAdapter={AdapterDateFns}>
  <StaticDatePicker
    displayStaticWrapperAs="desktop"
    openTo="day"
    value={value}
    onChange={(newValue) => {
      setValue(newValue);
    }}
    renderInput={(params) => <TextField {...params} />}
  />
</LocalizationProvider>`,children:e.jsxs(g,{spacing:3,children:[e.jsx(m,{dateAdapter:p,children:e.jsx(P,{displayStaticWrapperAs:"desktop",openTo:"year",value:r,onChange:a=>{t(a)}})}),e.jsx(m,{dateAdapter:p,children:e.jsx(P,{displayStaticWrapperAs:"desktop",openTo:"day",value:r,onChange:a=>{t(a)}})})]})})}const I=new Date("2020-01-01T00:00:00.000"),H=new Date("2034-01-01T00:00:00.000");function La(){const[r,t]=v.useState(new Date);return e.jsx(f,{title:"Sub Component",codeString:`<LocalizationProvider dateAdapter={AdapterDateFns}>
  <Stack spacing={3} justifyContent="center" alignItems="center">
    <Box sx={{ maxWidth: 320 }}>
      <YearCalendar value={date} minDate={minDate} maxDate={maxDate} onChange={(newDate: Date) => setDate(newDate)} />
    </Box>
    <Box sx={{ maxWidth: 320 }}>
      <MonthPicker date={date} minDate={minDate} maxDate={maxDate} onChange={(newDate) => setDate(newDate)} sx={{ m: 'auto' }} />
    </Box>
    <Box sx={{ maxWidth: 320 }}>
      <CalendarPicker date={date} onChange={(newDate) => setDate(newDate)} />
    </Box>
  </Stack>
</LocalizationProvider>`,children:e.jsx(m,{dateAdapter:p,children:e.jsxs(g,{spacing:3,justifyContent:"center",alignItems:"center",children:[e.jsx(k,{sx:{maxWidth:320},children:e.jsx(me,{value:r,minDate:I,maxDate:H,onChange:a=>t(a)})}),e.jsx(k,{sx:{maxWidth:320},children:e.jsx(he,{value:r,minDate:I,maxDate:H,onChange:a=>t(a),sx:{m:"auto"}})}),e.jsx(k,{sx:{maxWidth:320},children:e.jsx(pe,{value:r,onChange:a=>t(a)})})]})})})}function $a(){const[r,t]=v.useState(new Date);return e.jsx(f,{title:"Landscape",codeString:`<LocalizationProvider dateAdapter={AdapterDateFns}>
  <StaticDatePicker<Date>
    orientation="landscape"
    openTo="day"
    value={value}
    shouldDisableDate={isWeekend}
    onChange={(newValue) => {
      setValue(newValue);
    }}
    renderInput={(params) => <TextField {...params} />}
  />
</LocalizationProvider>`,children:e.jsx(m,{dateAdapter:p,children:e.jsx(P,{orientation:"landscape",openTo:"day",value:r,shouldDisableDate:we,onChange:a=>{t(a)}})})})}function Oa(){const[r,t]=v.useState(new Date("2014-08-18T21:11:54")),i=o=>{t(o)};return e.jsx(f,{title:"Basic Picker",codeString:`<LocalizationProvider dateAdapter={AdapterDateFns}>
  <Stack spacing={3}>
    <DesktopDatePicker
      label="Date Desktop"
      inputFormat="MM/dd/yyyy"
      value={value}
      onChange={handleChange}
      renderInput={(params) => <TextField {...params} />}
    />
    <MobileDatePicker
      label="Date Mobile"
      inputFormat="MM/dd/yyyy"
      value={value}
      onChange={handleChange}
      renderInput={(params) => <TextField {...params} />}
    />
    <TimePicker label="Time" value={value} onChange={handleChange} renderInput={(params) => <TextField {...params} />} />
    <DateTimePicker
      label="Date & Time Picker"
      value={value}
      onChange={handleChange}
      renderInput={(params) => <TextField {...params} />}
    />
  </Stack>
</LocalizationProvider>`,children:e.jsx(m,{dateAdapter:p,children:e.jsxs(g,{spacing:3,children:[e.jsx(ie,{format:"MM/dd/yyyy",value:r,onChange:i}),e.jsx(ge,{format:"MM/dd/yyyy",value:r,onChange:i}),e.jsx(j,{value:r,onChange:i}),e.jsx(W,{value:r,onChange:i})]})})})}function Na(){return e.jsx(f,{title:"Native Picker",codeString:`<TextField
  id="date"
  placeholder="Birthday"
  type="date"
  defaultValue="2017-05-24"
  sx={{ width: 220 }}
  InputLabelProps={{
    shrink: true
  }}
/>
<TextField
  id="time"
  placeholder="Alarm Clock"
  type="time"
  defaultValue="07:30"
  InputLabelProps={{
    shrink: true
  }}
  inputProps={{
    step: 300 // 5 min
  }}
  sx={{ width: 150 }}
/>
<TextField
  id="datetime-local"
  placeholder="Next Appointment"
  type="datetime-local"
  defaultValue="2017-05-24T10:30"
  sx={{ width: 250 }}
  InputLabelProps={{
    shrink: true
  }}
/>`,children:e.jsxs(g,{component:"form",noValidate:!0,spacing:3,children:[e.jsx(D,{id:"date",placeholder:"Birthday",type:"date",defaultValue:"2017-05-24",sx:{width:220},InputLabelProps:{shrink:!0}}),e.jsx(D,{id:"time",placeholder:"Alarm Clock",type:"time",defaultValue:"07:30",InputLabelProps:{shrink:!0},inputProps:{step:300},sx:{width:150}}),e.jsx(D,{id:"datetime-local",placeholder:"Next Appointment",type:"datetime-local",defaultValue:"2017-05-24T10:30",sx:{width:250},InputLabelProps:{shrink:!0}})]})})}const J={"en-us":void 0,"en-gb":na,"zh-cn":za,de:Ue};function Ia(){const[r,t]=v.useState("en-us"),i=o=>{t(o)};return e.jsx(f,{title:"Localization Picker",codeString:`<LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={localeMap[locale]}>
  <div>
    <ToggleButtonGroup value={locale} exclusive sx={{ mb: 2, display: 'block' }}>
      {Object.keys(localeMap).map((localeItem) => (
        <ToggleButton key={localeItem} value={localeItem} onClick={() => selectLocale(localeItem)}>
          {localeItem}
        </ToggleButton>
      ))}
    </ToggleButtonGroup>
    <DatePicker
      mask={maskMap[locale]}
      value={value}
      onChange={(newValue) => setValue(newValue)}
      renderInput={(params) => <TextField {...params} />}
    />
  </div>
</LocalizationProvider>`,children:e.jsx(m,{dateAdapter:p,adapterLocale:J[r],children:e.jsxs(g,{spacing:3,sx:{width:300},children:[e.jsx(fe,{value:r,exclusive:!0,fullWidth:!0,children:Object.keys(J).map(o=>e.jsx(ye,{value:o,onClick:()=>i(o),children:o},o))}),e.jsx(oe,{label:"Date",defaultValue:new Date("2022-04-17")}),e.jsx(ve,{label:"Time",defaultValue:new Date("2022-04-17T18:30")})]})})})}function Ha(){const[r,t]=v.useState(null);return e.jsx(f,{title:"Helper Text",codeString:`<LocalizationProvider dateAdapter={AdapterDateFns}>
  <DatePicker  
    value={value}
    onChange={(newValue) => {
      setValue(newValue);
    }}
    renderInput={(params) => <TextField {...params} helperText={params?.inputProps?.placeholder} placeholder="Helper Text" />}
  />
</LocalizationProvider>`,children:e.jsx(m,{dateAdapter:p,children:e.jsx(T,{value:r,onChange:a=>{t(a)},slotProps:{textField:{placeholder:"Helper Text",helperText:"Helper Text"}}})})})}function Ja(){const[r,t]=v.useState(null);return e.jsx(f,{title:"Disabled Pickers",codeString:`<MainCard title="Disabled Pickers" codeString={disabledDatepickerCodeString}>
  <Stack spacing={3}>
    <Typography variant="h6">Date Picker</Typography>
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <DatePicker
        label="disabled"
        disabled
        value={value}
        onChange={(newValue: any) => {
          setValue(newValue);
        }}
        renderInput={(params: any) => <TextField {...params} />}
      />
      <DatePicker
        label="read-only"
        readOnly
        value={value}
        onChange={(newValue: any) => {
          setValue(newValue);
        }}
        renderInput={(params: any) => <TextField {...params} />}
      />
    </LocalizationProvider>

    <Typography variant="h6">Date Time Picker</Typography>
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <DateTimePicker
        label="disabled"
        disabled
        value={value}
        onChange={(newValue: any) => {
          setValue(newValue);
        }}
        renderInput={(params: any) => <TextField {...params} />}
      />
      <DateTimePicker
        label="read-only"
        readOnly
        value={value}
        onChange={(newValue: any) => {
          setValue(newValue);
        }}
        renderInput={(params: any) => <TextField {...params} />}
      />

      <Typography variant="h6">Time Picker</Typography>
      <TimePicker
        label="disabled"
        disabled
        value={value}
        onChange={(newValue: any) => {
          setValue(newValue);
        }}
        renderInput={(params: any) => <TextField {...params} />}
      />
      <TimePicker
        label="read-only"
        readOnly
        value={value}
        onChange={(newValue: any) => {
          setValue(newValue);
        }}
        renderInput={(params: any) => <TextField {...params} />}
      />
    </LocalizationProvider>
  </Stack>
</MainCard>`,children:e.jsxs(g,{spacing:3,sx:{"& .MuiInputLabel-root":{overflow:"visible"}},children:[e.jsx(M,{variant:"h6",children:"Date Picker"}),e.jsxs(m,{dateAdapter:p,children:[e.jsx(T,{disabled:!0,value:r,onChange:a=>{t(a)},slotProps:{textField:{placeholder:"disabled"}}}),e.jsx(T,{readOnly:!0,value:r,onChange:a=>{t(a)},slotProps:{textField:{placeholder:"disabled"}}})]}),e.jsx(M,{variant:"h6",children:"Date Time Picker"}),e.jsxs(m,{dateAdapter:p,children:[e.jsx(W,{disabled:!0,value:r,onChange:a=>{t(a)},slotProps:{textField:{placeholder:"disabled"}}}),e.jsx(W,{readOnly:!0,value:r,onChange:a=>{t(a)},slotProps:{textField:{placeholder:"read-only"}}}),e.jsx(M,{variant:"h6",children:"Time Picker"}),e.jsx(j,{disabled:!0,value:r,onChange:a=>{t(a)},slotProps:{textField:{placeholder:"disabled"}}}),e.jsx(j,{readOnly:!0,value:r,onChange:a=>{t(a)},slotProps:{textField:{placeholder:"read-only"}}})]})]})})}function tt(){return e.jsxs(ae,{children:[e.jsx(te,{title:"Date / Time Picker",caption:"Date pickers let the user select a date.",directory:"src/pages/components-overview/date-time-picker",link:"https://mui.com/x/react-date-pickers/getting-started/"}),e.jsx(ne,{children:e.jsxs(C,{container:!0,spacing:3,children:[e.jsx(C,{item:!0,xs:12,lg:6,children:e.jsxs(g,{spacing:3,children:[e.jsx(Aa,{}),e.jsx(La,{}),e.jsx($a,{})]})}),e.jsx(C,{item:!0,xs:12,lg:6,children:e.jsxs(g,{spacing:3,children:[e.jsx(Oa,{}),e.jsx(Ha,{}),e.jsx(Na,{}),e.jsx(Ia,{}),e.jsx(Ja,{})]})})]})})]})}export{tt as default};
