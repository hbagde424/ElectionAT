function n(e){return e&&e.replace(/^\s+/g,"")}function u(e){return e&&e.replace(/\s+$/g," ")}function i(e){return r=>{const t=n(u(r.target.value));e.setFieldValue(r.target.name,t)}}export{i as t};
