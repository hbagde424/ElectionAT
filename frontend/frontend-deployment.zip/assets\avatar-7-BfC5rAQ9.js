const a="/election/assets/avatar-7-YqAYXBwS.png";export{a};
