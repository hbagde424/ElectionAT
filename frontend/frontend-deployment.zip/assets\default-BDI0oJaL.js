const e="/election/assets/default-CgtsF9c7.png";export{e as d};
