import{r as c,j as u}from"./index-Ba4Gy4r-.js";import{L as s}from"./leaflet-CEkKdnlD.js";const f=()=>{const l=c.useRef(null),e=c.useRef(null);c.useRef(null);const i=c.useRef(null),a=c.useRef(null);c.useEffect(()=>{if(!e.current&&l.current){e.current=s.map(l.current).setView([22.3349,74.7499],10);const t=s.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{maxZoom:18}).addTo(e.current),r=s.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",{maxZoom:18}),n={"Street Map":t,"Satellite View":r};s.control.layers(n).addTo(e.current),b()}return()=>{e.current&&(e.current.remove(),e.current=null)}},[]);const m=()=>{e.current&&e.current.eachLayer(t=>{t instanceof s.GeoJSON&&e.current.removeLayer(t)})},b=async()=>{try{const r=await(await fetch("/mapwork/Gandhwani.json")).json();m(),d(r)}catch(t){console.error("Error loading Gandhwani data:",t)}},d=t=>{i.current&&e.current.removeLayer(i.current),i.current=s.geoJSON(t,{style:{color:"gray",weight:2,fillOpacity:0},onEachFeature:(r,n)=>{n.bindTooltip(r.properties.BlockName,{permanent:!1,direction:"top"});const o=`
                    <b>Block Details:</b><br>
                    <b>Block Name:</b> ${r.properties.BlockName}<br>
                    <b>State Name:</b> ${r.properties.ST_NAME}<br>
                    <b>District Name:</b> ${r.properties.DIST_NAME}<br>
                    <b>Parliament Name:</b> ${r.properties.PC_NAME}<br>
                    <b>District Name:</b> ${r.properties.dtname11}
                `;n.bindPopup(o),n.on({mouseover:()=>n.openPopup(),mouseout:()=>n.closePopup(),click:()=>h(t,r.properties.BlockName)})}}).addTo(e.current),i.current&&e.current.fitBounds(i.current.getBounds())},h=(t,r)=>{a.current&&e.current.removeLayer(a.current);const n={type:"FeatureCollection",features:t.features.filter(o=>o.properties.BlockName===r)};a.current=s.geoJSON(n,{style:{color:"blue",weight:2,fillOpacity:0},onEachFeature:(o,p)=>{p.bindTooltip(o.properties.BoothName,{permanent:!1,direction:"top"});const N=`
                    <b>Booth Details:</b><br>
                    <b>Block Name:</b> ${o.properties.BlockName}<br>
                    <b>Booth Name:</b> ${o.properties.BoothName}<br>
                    <b>State Name:</b> ${o.properties.ST_NAME}<br>
                    <b>District Name:</b> ${o.properties.DIST_NAME}<br>
                    <b>Parliament Name:</b> ${o.properties.PC_NAME}<br>
                    <b>District Name:</b> ${o.properties.dtname11}<br>
                    <b>Booth No:</b> ${o.properties.BoothNo}
                `;p.bindPopup(N),p.on({mouseover:()=>p.openPopup(),mouseout:()=>p.closePopup()})}}).addTo(e.current),a.current&&e.current.fitBounds(a.current.getBounds())};return u.jsx("div",{ref:l,style:{height:"100vh",width:"100%"}})},g=()=>u.jsx("div",{style:{height:"100%",width:"100%"},children:u.jsx(f,{})});export{g as default};
