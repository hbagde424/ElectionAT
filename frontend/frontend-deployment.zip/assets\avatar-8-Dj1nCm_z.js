const a="/election/assets/avatar-8-BvgybMTX.png";export{a};
