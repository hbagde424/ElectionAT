const e="/election/assets/vector-1-8-ZvbKlG.png";export{e as v};
