import{aR as o}from"./index-Ba4Gy4r-.js";const l=o("div")({width:"100%",overflowX:"auto",display:"block"}),r=l;export{r as S};
