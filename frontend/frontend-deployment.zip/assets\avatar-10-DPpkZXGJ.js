const a="/election/assets/avatar-10-CL4STkrm.png";export{a};
