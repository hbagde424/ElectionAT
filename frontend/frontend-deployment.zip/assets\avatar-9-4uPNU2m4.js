const a="/election/assets/avatar-9-DBmDnH67.png";export{a};
