import{r as B,j as a,G as t,S as p,l as e,p as r,a3 as s,dj as z,E as k,ah as i,q as l,a6 as D,c4 as w,aL as U,ai as G,i as j,B as A,aj as S,T as N}from"./index-Ba4Gy4r-.js";import{C as W,a as H,b as P}from"./ComponentSkeleton-z_9Iszgd.js";import{a as n}from"./avatar-1-5oskpm9S.js";import{a as c}from"./avatar-2-Daz9s2l2.js";import{a as u}from"./avatar-3-CiFG_RPv.js";import{a as m}from"./avatar-4-DW8yftoJ.js";import{a as o}from"./avatar-5-CpOABgf7.js";import{a as d}from"./avatar-7-BfC5rAQ9.js";import{a as v}from"./avatar-8-Dj1nCm_z.js";import{a as g}from"./avatar-9-4uPNU2m4.js";import{a as h}from"./avatar-10-DPpkZXGJ.js";import{v as L}from"./vector-1-DEnYwOP3.js";import{S as R}from"./Sms-BR9XuZ-x.js";import{C as q}from"./Coin-Dd4DUBOE.js";import{A as x}from"./AvatarGroup-Chlh4ULC.js";import"./Skeleton-CsVZ7OH8.js";const C="/election/assets/vector-2-sis5eExl.png",J="/election/assets/vector-3-DIBkRP6w.png",K="/election/assets/vector-4-Cb2UqCjp.png";function ua(){const[y,b]=B.useState(!1),[T,f]=B.useState(!1);return a.jsxs(W,{children:[a.jsx(H,{title:"Avatar",caption:"Avatars are found throughout material design with uses in everything from tables to dialog menus.",directory:"src/pages/components-overview/avatars",link:"https://mui.com/material-ui/react-avatar/"}),a.jsx(P,{children:a.jsxs(t,{container:!0,spacing:3,children:[a.jsx(t,{item:!0,xs:12,lg:6,children:a.jsxs(p,{spacing:3,children:[a.jsx(e,{title:"Basic",codeHighlight:!0,codeString:'<Avatar alt="Basic"><Profile variant="Bold" /></Avatar>',children:a.jsx(r,{alt:"Basic",children:a.jsx(s,{variant:"Bold"})})}),a.jsx(e,{title:"Vector",codeString:`<Avatar><img alt="Natacha" src={('/assets/images/users/vector-1.png')} height={40} /></Avatar>
<Avatar><img alt="Natacha" src={('/assets/images/users/vector-2.png')} height={40} /></Avatar>
<Avatar><img alt="Natacha" src={('/assets/images/users/vector-3.png')} height={40} /></Avatar>
<Avatar><img alt="Natacha" src={('/assets/images/users/vector-4.png')} height={40} /></Avatar>`,children:a.jsxs(t,{container:!0,spacing:1,children:[a.jsx(t,{item:!0,children:a.jsx(r,{children:a.jsx("img",{alt:"Natacha",src:L,height:40})})}),a.jsx(t,{item:!0,children:a.jsx(r,{children:a.jsx("img",{alt:"Natacha",src:C,height:40})})}),a.jsx(t,{item:!0,children:a.jsx(r,{children:a.jsx("img",{alt:"Natacha",src:J,height:40})})}),a.jsx(t,{item:!0,children:a.jsx(r,{children:a.jsx("img",{alt:"Natacha",src:K,height:40})})})]})}),a.jsx(e,{title:"Variants",codeString:`<Avatar alt="Natacha"><Profile variant="Bold" /></Avatar>
<Avatar alt="Natacha" variant="rounded" type="combined" variant="Bold"><Profile /></Avatar>
<Avatar alt="Natacha" variant="square" type="filled"><Profile /></Avatar>
<Avatar alt="Natacha">U</Avatar>
<Avatar alt="Natacha" variant="rounded" type="combined">U</Avatar>
<Avatar alt="Natacha" variant="square" type="filled">U</Avatar>`,children:a.jsxs(t,{container:!0,spacing:1,children:[a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",children:a.jsx(s,{variant:"Bold"})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",variant:"rounded",type:"combined",children:a.jsx(s,{variant:"Bold"})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",variant:"square",type:"filled",children:a.jsx(s,{})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",children:"U"})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",variant:"rounded",type:"combined",children:"U"})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",variant:"square",type:"filled",children:"U"})})]})}),a.jsx(e,{title:"Icon",codeString:`<Avatar alt="Natacha" size="sm" type="filled"><Profile /></Avatar>
<Avatar alt="Natacha" size="sm" type="filled" color="success"><SearchZoomIn /></Avatar>
<Avatar alt="Natacha" size="sm" type="filled" color="error"><SearchZoomOut1 /></Avatar>
<Avatar alt="Natacha" size="sm"><Add /></Avatar>`,children:a.jsxs(t,{container:!0,spacing:1,children:[a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",size:"sm",type:"filled",children:a.jsx(s,{variant:"Bold"})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",size:"sm",type:"filled",color:"success",children:a.jsx(R,{variant:"Bold"})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",size:"sm",type:"filled",color:"error",children:a.jsx(z,{variant:"Bold"})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",size:"sm",children:a.jsx(k,{})})})]})}),a.jsx(e,{title:"With Badge",codeString:`<Badge badgeContent={4} color="error" overlap="circular">
  <Avatar alt="Natacha" type="filled" src={('/assets/images/users/avatar-6.png')} />
</Badge>
<Badge color="error" overlap="circular" variant="dot">
  <Avatar alt="Natacha" color="secondary" type="filled">
    <Profile />
  </Avatar>
</Badge>
<Badge color="error" overlap="circular" variant="dot">
  <Avatar alt="Natacha" type="filled" src={('/assets/images/users/avatar-2.png')} />
</Badge>
<Badge color="error" overlap="circular" variant="dot">
  <Avatar alt="Natacha" type="outlined">
    U
  </Avatar>
</Badge>
<Badge color="error" overlap="circular" variant="dot">
  <Avatar>
    <img alt="Natacha" src={('/assets/images/users/vector-2.png')} width={40} />
  </Avatar>
</Badge>
<Badge color="success" variant="dot">
  <Avatar alt="Natacha" variant="rounded" type="filled" src={('/assets/images/users/avatar-1.png')} />
</Badge>
<Badge
  overlap="circular"
  anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
  badgeContent={<Avatar size="badge" alt="Remy Sharp" src={('/assets/images/users/avatar-6.png')} />}
>
  <Avatar alt="Travis Howard" src={('/assets/images/users/avatar-1.png')} />
</Badge>`,children:a.jsxs(t,{container:!0,spacing:1,children:[a.jsx(t,{item:!0,children:a.jsx(i,{badgeContent:4,color:"error",overlap:"circular",children:a.jsx(r,{alt:"Natacha",type:"filled",src:l})})}),a.jsx(t,{item:!0,children:a.jsx(i,{color:"error",overlap:"circular",variant:"dot",children:a.jsx(r,{alt:"Natacha",color:"secondary",type:"filled",children:a.jsx(s,{})})})}),a.jsx(t,{item:!0,children:a.jsx(i,{color:"error",overlap:"circular",variant:"dot",children:a.jsx(r,{alt:"Natacha",type:"filled",src:c})})}),a.jsx(t,{item:!0,children:a.jsx(i,{color:"error",overlap:"circular",variant:"dot",children:a.jsx(r,{alt:"Natacha",type:"outlined",children:"U"})})}),a.jsx(t,{item:!0,children:a.jsx(i,{color:"error",overlap:"circular",variant:"dot",children:a.jsx(r,{children:a.jsx("img",{alt:"Natacha",src:C,width:40})})})}),a.jsx(t,{item:!0,children:a.jsx(i,{color:"success",variant:"dot",children:a.jsx(r,{alt:"Natacha",variant:"rounded",type:"filled",src:n})})}),a.jsx(t,{item:!0,children:a.jsx(i,{overlap:"circular",anchorOrigin:{vertical:"bottom",horizontal:"right"},badgeContent:a.jsx(r,{size:"badge",alt:"Remy Sharp",src:l}),children:a.jsx(r,{alt:"Travis Howard",src:n})})})]})}),a.jsx(e,{title:"Image",codeString:`<Avatar alt="Avatar 1" src={('/assets/images/users/avatar-1.png')} />
<Avatar alt="Avatar 2" src={('/assets/images/users/avatar-2.png')} />
<Avatar alt="Avatar 3" src={('/assets/images/users/avatar-3.png')} />
<Avatar alt="Avatar 4" src={('/assets/images/users/avatar-4.png')} />`,children:a.jsxs(t,{container:!0,spacing:1,children:[a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Avatar 1",src:n})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Avatar 2",src:c})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Avatar 3",src:u})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Avatar 4",src:m})})]})}),a.jsx(e,{title:"Colors",codeString:`<Avatar alt="Basic" type="filled"><Profile variant="Bold" /></Avatar>
<Avatar alt="Basic" type="filled" color="error"><Trash variant="Bold" /></Avatar>
<Avatar alt="Basic" type="filled" color="info"><InfoCircle variant="Bold" /></Avatar>
<Avatar alt="Basic" type="filled" color="warning"><Warning2 variant="Bold" /></Avatar>
<Avatar alt="Basic" type="filled" color="success"><TickCircle variant="Bold" /></Avatar>
<Avatar alt="Basic" type="filled" color="secondary"><Coin variant="Bold" /></Avatar>`,children:a.jsxs(t,{container:!0,spacing:1,children:[a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Basic",type:"filled",children:a.jsx(s,{})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Basic",type:"filled",color:"secondary",children:a.jsx(q,{})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Basic",type:"filled",color:"success",children:a.jsx(D,{})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Basic",type:"filled",color:"warning",children:a.jsx(w,{})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Basic",type:"filled",color:"info",children:a.jsx(U,{})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Basic",type:"filled",color:"error",children:a.jsx(G,{})})})]})})]})}),a.jsx(t,{item:!0,xs:12,lg:6,children:a.jsxs(p,{spacing:3,children:[a.jsx(e,{title:"Letter",codeString:`<Avatar alt="Natacha" size="sm">U</Avatar>
<Avatar color="error" alt="Natacha" size="sm">UI</Avatar>
<Avatar color="error" type="filled" alt="Natacha" size="sm">A</Avatar>`,children:a.jsxs(t,{container:!0,spacing:1,children:[a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",size:"sm",children:"U"})}),a.jsx(t,{item:!0,children:a.jsx(r,{color:"error",alt:"Natacha",size:"sm",children:"UI"})}),a.jsx(t,{item:!0,children:a.jsx(r,{color:"error",type:"filled",alt:"Natacha",size:"sm",children:"A"})})]})}),a.jsx(e,{title:"Outlined",codeString:`<Avatar alt="Natacha" type="outlined"><Profile variant="Bold" /></Avatar>
<Avatar alt="Natacha" variant="rounded" type="outlined"><Profile variant="Bold" /></Avatar>
<Avatar alt="Natacha" variant="square" type="outlined"><Profile variant="Bold" /></Avatar>
<Avatar alt="Natacha" type="outlined">U</Avatar>
<Avatar alt="Natacha" variant="rounded" type="outlined">U</Avatar>
<Avatar alt="Natacha" variant="square" type="outlined">U</Avatar>`,children:a.jsxs(t,{container:!0,spacing:1,children:[a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",type:"outlined",children:a.jsx(s,{variant:"Bold"})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",variant:"rounded",type:"outlined",children:a.jsx(s,{variant:"Bold"})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",variant:"square",type:"outlined",children:a.jsx(s,{variant:"Bold"})})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",type:"outlined",children:"U"})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",variant:"rounded",type:"outlined",children:"U"})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Natacha",variant:"square",type:"outlined",children:"U"})})]})}),a.jsxs(e,{title:"Avatar Group",codeString:`<AvatarGroup max={4}>
  <Avatar alt="Trevor Henderson" src={('/assets/images/users/avatar-5.png')} />
  <Avatar alt="Jone Doe" src={('/assets/images/users/avatar-6.png')} />
  <Avatar alt="Lein Ket" src={('/assets/images/users/avatar-7.png')} />
  <Avatar alt="Stebin Ben" src={('/assets/images/users/avatar-8.png')} />
  <Avatar alt="Wungh Tend" src={('/assets/images/users/avatar-9.png')} />
  <Avatar alt="Trevor Das" src={('/assets/images/users/avatar-10.png')} />
</AvatarGroup>
<Box sx={{ width: 186 }}>
  <Tooltip
    open={show}
    placement="top-end"
    title={
      <AvatarGroup max={10}>
        <Avatar alt="Trevor Henderson" src={('/assets/images/users/avatar-5.png')} />
        <Avatar alt="Jone Doe" src={('/assets/images/users/avatar-6.png')} />
        <Avatar alt="Lein Ket" src={('/assets/images/users/avatar-7.png')} />
        <Avatar alt="Stebin Ben" src={('/assets/images/users/avatar-8.png')} />
        <Avatar alt="Wungh Tend" src={('/assets/images/users/avatar-9.png')} />
        <Avatar alt="Trevor Das" src={('/assets/images/users/avatar-10.png')} />
      </AvatarGroup>
    }
  >
    <AvatarGroup
      sx={{ '& .MuiAvatarGroup-avatar': { bgcolor: 'primary.main', cursor: 'pointer' } }}
      componentsProps={{
        additionalAvatar: {
          onMouseEnter: () => {
            setShow(true);
          },
          onMouseLeave: () => {
            setShow(false);
          }
        }
      }}
    >
      <Avatar alt="Remy Sharp" src={('/assets/images/users/avatar-1.png')} />
      <Avatar alt="Travis Howard" src={('/assets/images/users/avatar-2.png')} />
      <Avatar alt="Cindy Baker" src={('/assets/images/users/avatar-3.png')} />
      <Avatar alt="Agnes Walker" src={('/assets/images/users/avatar-4.png')} />
      <Avatar alt="Trevor Henderson" src={('/assets/images/users/avatar-5.png')} />
      <Avatar alt="Jone Doe" src={('/assets/images/users/avatar-6.png')} />
      <Avatar alt="Lein Ket" src={('/assets/images/users/avatar-7.png')} />
      <Avatar alt="Stebin Ben" src={('/assets/images/users/avatar-8.png')} />
      <Avatar alt="Wungh Tend" src={('/assets/images/users/avatar-9.png')} />
      <Avatar alt="Trevor Das" src={('/assets/images/users/avatar-10.png')} />
    </AvatarGroup>
  </Tooltip>
</Box>
<Box sx={{ width: 222 }}>
  <Tooltip
    open={open}
    placement="top-end"
    title={
      <AvatarGroup max={10}>
        <Avatar alt="Jone Doe" src={('/assets/images/users/avatar-6.png')} />
        <Avatar alt="Lein Ket" src={('/assets/images/users/avatar-7.png')} />
        <Avatar alt="Stebin Ben" src={('/assets/images/users/avatar-8.png')} />
        <Avatar alt="Wungh Tend" src={('/assets/images/users/avatar-9.png')} />
        <Avatar alt="Trevor Das" src={('/assets/images/users/avatar-10.png')} />
      </AvatarGroup>
    }
  >
    <AvatarGroup
      max={6}
      sx={{ '& .MuiAvatarGroup-avatar': { bgcolor: 'primary.main', cursor: 'pointer' } }}
      componentsProps={{
        additionalAvatar: {
          onClick: () => {
            setOpen(!open);
          }
        }
      }}
    >
      <Avatar alt="Remy Sharp" src={('/assets/images/users/avatar-1.png')} />
      <Avatar alt="Travis Howard" src={('/assets/images/users/avatar-2.png')} />
      <Avatar alt="Cindy Baker" src={('/assets/images/users/avatar-3.png')} />
      <Avatar alt="Agnes Walker" src={('/assets/images/users/avatar-4.png')} />
      <Avatar alt="Trevor Henderson" src={('/assets/images/users/avatar-5.png')} />
      <Avatar alt="Jone Doe" src={('/assets/images/users/avatar-6.png')} />
      <Avatar alt="Lein Ket" src={('/assets/images/users/avatar-7.png')} />
      <Avatar alt="Stebin Ben" src={('/assets/images/users/avatar-8.png')} />
      <Avatar alt="Wungh Tend" src={('/assets/images/users/avatar-9.png')} />
      <Avatar alt="Trevor Das" src={('/assets/images/users/avatar-10.png')} />
    </AvatarGroup>
  </Tooltip>
</Box>`,children:[a.jsxs(p,{spacing:2,children:[a.jsx(j,{variant:"subtitle1",children:"Default"}),a.jsx(A,{sx:{width:148},children:a.jsxs(x,{max:4,children:[a.jsx(r,{alt:"Trevor Henderson",src:o}),a.jsx(r,{alt:"Jone Doe",src:l}),a.jsx(r,{alt:"Lein Ket",src:d}),a.jsx(r,{alt:"Stebin Ben",src:v}),a.jsx(r,{alt:"Wungh Tend",src:g}),a.jsx(r,{alt:"Trevor Das",src:h})]})}),a.jsx(S,{sx:{my:2}}),a.jsx(j,{variant:"subtitle1",children:"On Hover"}),a.jsx(A,{sx:{width:186},children:a.jsx(N,{open:T,placement:"top-end",title:a.jsxs(x,{max:10,children:[a.jsx(r,{alt:"Trevor Henderson",src:o}),a.jsx(r,{alt:"Jone Doe",src:l}),a.jsx(r,{alt:"Lein Ket",src:d}),a.jsx(r,{alt:"Stebin Ben",src:v}),a.jsx(r,{alt:"Wungh Tend",src:g}),a.jsx(r,{alt:"Trevor Das",src:h})]}),children:a.jsxs(x,{sx:{"& .MuiAvatarGroup-avatar":{bgcolor:"primary.main",cursor:"pointer"}},componentsProps:{additionalAvatar:{onMouseEnter:()=>{f(!0)},onMouseLeave:()=>{f(!1)}}},children:[a.jsx(r,{alt:"Remy Sharp",src:n}),a.jsx(r,{alt:"Travis Howard",src:c}),a.jsx(r,{alt:"Cindy Baker",src:u}),a.jsx(r,{alt:"Agnes Walker",src:m}),a.jsx(r,{alt:"Trevor Henderson",src:o}),a.jsx(r,{alt:"Jone Doe",src:l}),a.jsx(r,{alt:"Lein Ket",src:d}),a.jsx(r,{alt:"Stebin Ben",src:v}),a.jsx(r,{alt:"Wungh Tend",src:g}),a.jsx(r,{alt:"Trevor Das",src:h})]})})})]}),a.jsx(S,{sx:{my:2}}),a.jsxs(p,{spacing:2,children:[a.jsx(j,{variant:"subtitle1",children:"On Click"}),a.jsx(A,{sx:{width:222},children:a.jsx(N,{open:y,placement:"top-end",title:a.jsxs(x,{max:10,children:[a.jsx(r,{alt:"Jone Doe",src:l}),a.jsx(r,{alt:"Lein Ket",src:d}),a.jsx(r,{alt:"Stebin Ben",src:v}),a.jsx(r,{alt:"Wungh Tend",src:g}),a.jsx(r,{alt:"Trevor Das",src:h})]}),children:a.jsxs(x,{max:6,sx:{"& .MuiAvatarGroup-avatar":{bgcolor:"primary.main",cursor:"pointer"}},componentsProps:{additionalAvatar:{onClick:()=>{b(!y)}}},children:[a.jsx(r,{alt:"Remy Sharp",src:n}),a.jsx(r,{alt:"Travis Howard",src:c}),a.jsx(r,{alt:"Cindy Baker",src:u}),a.jsx(r,{alt:"Agnes Walker",src:m}),a.jsx(r,{alt:"Trevor Henderson",src:o}),a.jsx(r,{alt:"Jone Doe",src:l}),a.jsx(r,{alt:"Lein Ket",src:d}),a.jsx(r,{alt:"Stebin Ben",src:v}),a.jsx(r,{alt:"Wungh Tend",src:g}),a.jsx(r,{alt:"Trevor Das",src:h})]})})})]})]}),a.jsx(e,{title:"Sizes",codeString:`<Avatar size="xs" alt="Avatar 1" src={('/assets/images/users/avatar-1.png')} />
<Avatar size="xl" alt="Avatar 5" src={('/assets/images/users/avatar-5.png')} />
<Avatar size="lg" alt="Avatar 4" src={('/assets/images/users/avatar-4.png')} />
<Avatar size="md" alt="Avatar 3" src={('/assets/images/users/avatar-3.png')} />
<Avatar size="sm" alt="Avatar 2" src={('/assets/images/users/avatar-2.png')} />`,children:a.jsxs(t,{container:!0,spacing:1,alignItems:"center",children:[a.jsx(t,{item:!0,children:a.jsx(r,{size:"xs",alt:"Avatar 1",src:n})}),a.jsx(t,{item:!0,children:a.jsx(r,{size:"sm",alt:"Avatar 2",src:c})}),a.jsx(t,{item:!0,children:a.jsx(r,{size:"md",alt:"Avatar 3",src:u})}),a.jsx(t,{item:!0,children:a.jsx(r,{size:"lg",alt:"Avatar 4",src:m})}),a.jsx(t,{item:!0,children:a.jsx(r,{size:"xl",alt:"Avatar 5",src:o})})]})}),a.jsx(e,{title:"Fallbacks",codeString:`<Avatar alt="Remy Sharp" src="/broken-image.jpg" color="error" type="filled">B</Avatar>
<Avatar src="/broken-image.jpg" color="error" />
<Avatar alt="Remy Sharp" src="/broken-image.jpg" color="error" type="outlined" />`,children:a.jsxs(t,{container:!0,spacing:1,children:[a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Remy Sharp",src:"/broken-image.jpg",color:"error",type:"filled",children:"B"})}),a.jsx(t,{item:!0,children:a.jsx(r,{alt:"Remy Sharp",src:"/broken-image.jpg",color:"error",type:"outlined"})}),a.jsx(t,{item:!0,children:a.jsx(r,{src:"/broken-image.jpg",color:"error"})})]})})]})})]})})]})}export{ua as default};
