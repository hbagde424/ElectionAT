const a="/election/assets/avatar-2-BfYKEY4l.png";export{a};
